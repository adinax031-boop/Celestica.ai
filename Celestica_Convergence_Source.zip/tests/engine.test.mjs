import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT,orbit,verify,solve,fixed,ablation} from '../lab/axiom.mjs';
import {dataset,finish,averagePrecision} from '../lab/memory.mjs';

test('nominal period and eclipse are physically bounded',()=>{
 const o=orbit(DEFAULT);
 assert(o.period*60>90 && o.period*60<110);
 assert(o.eclipse>0 && o.eclipse<o.day);
 assert.equal(orbit({...DEFAULT,beta:75}).eclipse,0);
});
test('nonnegative hard margins and traced energy agree',()=>{
 const original=verify(DEFAULT,fixed,true);
 assert(original.pass);
 assert(original.events.every(e=>e.wh<=original.full));
 const fault={...DEFAULT,solarLoss:.48};
 assert(!verify(fault,fixed).pass);
 assert(solve(fault).design && verify(fault,solve(fault).design).pass);
 assert.equal(solve({...fault,ceiling:9}).design,null);
});
test('deterministic optimizer agrees with exhaustive verifier on the frozen set',()=>{
 const r=ablation();
 assert.equal(r.exact,160);assert.equal(r.falseAccept,0);
 assert.equal(r.fixedPass+r.gains-r.losses,r.solved);
 assert.equal(r.infeasible+r.solved,160);
});
test('replay, monitor, risk and test examples are separate from training',()=>{
 for(const mode of ['digits','engineering']){
  const {tasks}=dataset(mode,917);
  const ids=tasks.flatMap(t=>Object.values(t).flat().map(e=>e.id));
  assert.equal(new Set(ids).size,ids.length);
 }
});
test('live neural learning reproduces the reference mechanism and counts cost separately',()=>{
 const base=finish({policy:'sequential'}), replay=finish({policy:'replay'}), guard=finish({policy:'guard'});
 for(const row of [base,replay,guard]){
  assert.equal(row.parameters,1810);assert.equal(row.counts.trainingExamples,5280);
  assert.equal(row.metrics.length,5);assert(row.counts.diagnosticForwardExamples>0);
 }
 assert(base.newAccuracy>.9);
 assert(replay.retention>base.retention+.5);
 assert(guard.counts.monitorBackpropExamples>replay.counts.monitorBackpropExamples);
});
test('AP processes tied scores as a group',()=>{
 assert.equal(averagePrecision([{score:1,positive:true},{score:1,positive:false}]),.5);
 assert.equal(averagePrecision([{score:1,positive:false}]),null);
});
