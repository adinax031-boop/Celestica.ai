import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const requires=createRequire(import.meta.url);
const {parseHTML}=requires(process.env.CELESTICA_LINKEDOM||'linkedom');
const source=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
const {document,window}=parseHTML(source);
const scripts=Array.from(document.querySelectorAll('script'));
assert.equal(scripts.length,1);
assert(!document.querySelector('script[src],link[rel=stylesheet],iframe'));
const storage=new Map();
const config={window,document,performance,location:{protocol:'file:',hash:''},requestAnimationFrame:cb=>cb.name==="draw"?0:setImmediate(cb),
  localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},
  Event:window.Event,AbortSignal,console,URL,Blob,devicePixelRatio:1,setTimeout,fetch:()=>{throw Error('External request attempted');}};
for(const select of document.querySelectorAll('select')){
 Object.defineProperty(select,'value',{get(){return this.querySelector('[selected]')?.value??this.querySelector('option')?.value;},
   set(v){for(const opt of this.querySelectorAll('option'))opt.toggleAttribute('selected',opt.value===v);}});
}
for(const canvas of document.querySelectorAll('canvas')) canvas.getContext=()=>({});
vm.runInNewContext(scripts[0].textContent,config);
const get=id=>document.getElementById(id);
assert.match(get('mem-status').textContent,/Recorded local experiment/);
assert.match(get('axiom-status').textContent,/verified in this model/);
get('axiom-failure').onclick();
assert.match(get('axiom-status').textContent,/constraint failure/);
await get('axiom-redesign').onclick();
assert.match(get('axiom-status').textContent,/Minimum-mass verified/);
await get('kc-compile').onclick();
assert(!get('kc-cards').hidden);
get('kc-tests').onclick();
assert.match(get('kc-last').textContent,/Behavior tests passed/);
get('kc-mode').value='simulation';get('kc-mode').onchange();await get('kc-compile').onclick();get('kc-tests').onclick();
assert.match(get('kc-last').textContent,/Position 3|position 3/);
get('kc-mode').value='live';get('kc-mode').onchange();await get('kc-compile').onclick();
assert.match(get('kc-status').textContent,/unavailable/);
await get('memory-run').onclick();
assert.match(get('mem-status').textContent,/1810 trained parameters/);
assert(Math.max(...JSON.parse(storage.get('celestica-evidence-v1')).map(v=>v.lab==='Axiom'))===1);
console.log('PASS: self-contained bundle, initial state, fault, verified redesign, recorded KC, simulation, live failure state, persistent ledger');
