"""Local optional Qwen inference and WASI Rust verification for curated tasks."""
from functools import partial
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import argparse
import json
import os
from pathlib import Path
import sys
from threading import BoundedSemaphore
from urllib.parse import urlsplit
from urllib.request import Request, ProxyHandler, build_opener
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'kc'))
from cascade import PublicTask
from compiler_edit import analyze
from demo_tasks import demos
from local_model import Model, revision
from verify import verify, smoke
lock=BoundedSemaphore(1)

class LocalQwen(Model):
    def generate(self,task,extra=''):
        from dataclasses import replace
        original=super().generate(task,extra)
        return replace(original,model='Qwen2.5-Coder-0.5B Q4_K_M live')

def run_kc(t,model):
    task=PublicTask(t.id,t.prompt(),bool(t.broken),t.sig,t.prelude)
    first=model.generate(task)
    initial,diag,edit=analyze(task,first.body)
    selected,gate,second=first,initial,None
    body=first.body
    if initial!='compiled':
        if edit and analyze(task,edit)[0]=='compiled':
            body,gate=edit,'compiled'
        else:
            second=model.generate(task,revision(first,diag))
            g,_,_=analyze(task,second.body)
            if g=='compiled': selected,gate,body=second,g,second.body
    return {'id':t.id,'model':first.model,'initial':{'body':first.body or first.response,'compile':initial,'diag':diag,
            'functional':verify(t,first.body or '')[0]},'selected':{'body':body or selected.response,'compile':gate,'functional':verify(t,body or '')[0]},
            'calls':1+bool(second),'tokens':first.tokens+(second.tokens if second else 0),
            'seconds':first.seconds+(second.seconds if second else 0)}

def propose(model,problem):
    valid={'load':(12,70),'day':(0,2),'eclipse':(0,2),'solarLoss':(0,.8),'batteryLoss':(0,.8),'ceiling':(9,24)}
    if set(problem)!=set(valid) or not all(type(problem[k]) in (int,float) and lo<=problem[k]<=hi for k,(lo,hi) in valid.items()):
        raise ValueError('invalid spacecraft inputs')
    prompt='Choose a solar array and battery for this spacecraft. Your proposal is independently checked. Solar watts by ID 1–8: 36,48,64,80,100,120,145,172. Battery Wh by ID 1–8: 24,36,52,70,90,115,145,180. Reply only JSON with integer keys values solar and battery: {"solar":4,"battery":4}. Inputs: '+json.dumps(problem)
    req=Request(model.url+'/v1/chat/completions',json.dumps({'messages':[{'role':'user','content':prompt}],
       'temperature':0,'max_tokens':64}).encode(),{'Content-Type':'application/json'})
    with build_opener(ProxyHandler({})).open(req,timeout=70) as response:
        data=json.loads(response.read(2**20))
    raw=data['choices'][0]['message'].get('content','')
    import re
    part=re.search(r'\{[^{}]*\}',raw)
    try:
        d=json.loads(part.group()) if part else {}
        if set(d)=={'solar','battery'} and all(type(x)==int and 1<=x<=8 for x in d.values()):
            return {'design':d,'tokens':data['usage']['completion_tokens']}
    except (ValueError,TypeError): pass
    return {'design':None,'tokens':data['usage']['completion_tokens']}

class App(BaseHTTPRequestHandler):
    def __init__(self,*args,model,cases,**kw):
        self.model,self.cases=model,cases
        super().__init__(*args,**kw)
    def out(self,status,data,kind='application/json'):
        data=data if isinstance(data,bytes) else json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type',kind+'; charset=utf-8')
        self.send_header('Content-Length',str(len(data)))
        self.send_header('X-Content-Type-Options','nosniff')
        self.end_headers()
        self.wfile.write(data)
    def host(self): return self.headers.get('Host','').partition(':')[0] in {'127.0.0.1','localhost'}
    def do_GET(self):
        if not self.host(): return self.send_error(403)
        if self.path in ('/','/index.html'): return self.out(200,(ROOT/'index.html').read_bytes(),'text/html')
        if self.path=='/api/status': return self.out(200,{'live':bool(self.model)})
        return self.send_error(404)
    def do_POST(self):
        origin=urlsplit(self.headers.get('Origin',''))
        if not self.host() or (origin.netloc and origin.netloc!=self.headers.get('Host')): return self.send_error(403)
        if self.path not in ('/api/axiom/check','/api/axiom/propose') and not self.path.startswith('/api/kc/'):
            return self.send_error(404)
        if not lock.acquire(False): return self.out(429,{'error':'The local lab is busy'})
        try:
            if self.path in ('/api/axiom/check','/api/axiom/propose'):
                n=int(self.headers.get('Content-Length','0'))
                if not 0<n<=4096: return self.send_error(400)
                data=json.loads(self.rfile.read(n))
                if self.path.endswith('/check'):
                    from axiomforge.check import check_margins
                    return self.out(200,{'checks':check_margins(data)})
                if self.model: return self.out(200,propose(self.model,data))
            key=self.path.removeprefix('/api/kc/')
            if self.model and key in self.cases: return self.out(200,run_kc(self.cases[key],self.model))
            return self.send_error(404)
        except (BrokenPipeError,ConnectionResetError): pass
        except Exception as e:
            self.log_error('local verification failed (%s)',type(e).__name__)
            self.out(503,{'error':'Local verification unavailable. Use recorded or offline mode.'})
        finally: lock.release()

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--port',type=int,default=8040)
    p.add_argument('--model-url')
    a=p.parse_args()
    model=LocalQwen(a.model_url) if a.model_url else None
    cases={t.id:t for t in demos()}
    if model:
        smoke()
        if any(verify(t,t.body,trusted=True)[0]!='pass' for t in cases.values()):
            raise RuntimeError('Curated references failed')
    factory=partial(App,model=model,cases=cases)
    with ThreadingHTTPServer(('127.0.0.1',a.port),factory) as app:
        print(f'http://127.0.0.1:{a.port}',flush=True)
        app.serve_forever()
