export const DEFAULT = Object.freeze({altitude: 550, beta: 12, load: 36, ceiling: 18, solarLoss: 0, batteryLoss: 0, extraEclipse: 0});
const R = 6378.137, MU = 398600.4418, BUS = 8.6, DOD = .65, ETA_IN = .88, ETA_OUT = .92;
const solar = [36,48,64,80,100,120,145,172].map((w,i)=>({id:i+1,w,kg:.32+w/52}));
const batteries = [24,36,52,70,90,115,145,180].map((wh,i)=>({id:i+1,wh,kg:.26+wh/112}));
export const catalog = solar.flatMap(panel=>batteries.map(battery=>({panel,battery,id:`S${panel.id} / B${battery.id}`})));
export function orbit(c) {
  const r=R+c.altitude;
  const period=2*Math.PI*Math.sqrt(r**3/MU)/3600;
  const ratio=Math.sqrt(1-(R/r)**2)/Math.cos(c.beta*Math.PI/180);
  const frac=ratio>=1?0:Math.acos(ratio)/Math.PI;
  const eclipse=Math.min(period,period*frac+c.extraEclipse/60);
  return {period,eclipse,day:period-eclipse};
}
export function nominal(c,d) {
  const o=orbit(c);
  const draw=c.load*o.eclipse/ETA_OUT;
  return {draw, generation:d.panel.w*(1-c.solarLoss), usable:d.battery.wh*(1-c.batteryLoss)*DOD,
          mass:BUS+d.panel.kg+d.battery.kg, ...o};
}
export function verify(c,d,trace=false) {
  const o=orbit(c), full=d.battery.wh*(1-c.batteryLoss);
  const reserve=full*(1-DOD), out=c.load/ETA_OUT;
  const power=d.panel.w*(1-c.solarLoss), mass=BUS+d.panel.kg+d.battery.kg;
  const events=[];
  let charge=full, minimum=full, rate=(power-c.load)*(power>=c.load?ETA_IN:1/ETA_OUT);
  for(let k=0;k<4;k++){
    for(const [phase,duration,deduction] of [['Eclipse',o.eclipse,-out],['Sunlight',o.day,rate]]){
      const slices=Math.max(1,Math.ceil(duration*72));
      for(let j=0;j<slices;j++){
        charge=Math.min(full,charge+duration*deduction/slices);
        minimum=Math.min(charge,minimum);
        if(trace && k<2)events.push({phase,wh:charge,duration:duration/slices});
      }
    }
  }
  const checks=[
    {name:'Eclipse reserve',margin:minimum-reserve,unit:'Wh'},
    {name:'One-orbit recharge',margin:rate*o.day-out*o.eclipse,unit:'Wh'},
    {name:'Bus power in sunlight',margin:power-c.load,unit:'W'},
    {name:'Mass ceiling',margin:c.ceiling-mass,unit:'kg'}
  ].map(v=>({...v,pass:v.margin>=-1e-8}));
  return {pass:checks.every(v=>v.pass),checks,minimum,reserve,full,events,mass,...o};
}
export function solve(c) {
  const ordered=catalog.map(d=>({d,...nominal(c,d)})).sort((a,b)=>a.mass-b.mass||a.d.id.localeCompare(b.d.id));
  const possible=ordered.filter(n=>n.mass<=c.ceiling+1e-8&&n.usable>=n.draw-1e-8&&n.generation>=c.load-1e-8&&(n.generation-c.load)*ETA_IN*n.day>=n.draw-1e-8);
  const selected=possible.find(n=>verify(c,n.d).pass);
  return {design:selected?.d??null, considered:ordered.length, passedScreen:possible.length};
}
export const fixed=catalog[3*8+3];
export function rng(seed){let s=seed>>>0;return ()=>{s=(Math.imul(1664525,s)+1013904223)>>>0;return s/4294967296;};}
export function sample(r,task) {
 return {altitude:350+600*r(),beta:65*r(),load:15+45*r(),ceiling:12+7*r(),
   solarLoss:task===1?.12+.38*r():.15*r(),batteryLoss:task===1?.12+.37*r():.14*r(),
   extraEclipse:task===1?12*r():0};
}
export function ablation(n=160,seed=7264){
 const r=rng(seed);let fixedPass=0,solved=0,exact=0,falseAccept=0,infeasible=0,gains=0,losses=0;
 for(let i=0;i<n;i++){
  const c=sample(r,i%2), incumbent=verify(c,fixed).pass, result=solve(c);
  const best=catalog.filter(d=>verify(c,d).pass).sort((a,b)=>verify(c,a).mass-verify(c,b).mass)[0];
  const verified=result.design&&verify(c,result.design);
  if(incumbent)fixedPass++;
  if(verified?.pass)solved++;
  if(verified?.pass&&!incumbent)gains++;
  if(incumbent&&!verified?.pass)losses++;
  if(!best)infeasible++;
  if(result.design&&!verified?.pass)falseAccept++;
  if((!result.design&&!best)||(verified?.pass&&best&&Math.abs(verified.mass-verify(c,best).mass)<1e-7))exact++;
 }
 return {n,seed,fixedPass,solved,exact,falseAccept,infeasible,gains,losses,catalog:catalog.length};
}
