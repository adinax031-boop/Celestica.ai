import {train,POLICIES} from './memory.mjs';
import {DEFAULT,orbit,verify,solve,fixed,catalog} from './axiom.mjs';
import {mountOrbit} from './orbit-view.mjs';
import evidence from '../evidence/benchmark.json';
import archive from '../evidence/kc.json';
const $=id=>document.getElementById(id), put=(id,s)=>{$(id).textContent=s;};
const node=(tag,txt,cls)=>{const x=document.createElement(tag);if(txt!==undefined)x.textContent=txt;if(cls)x.className=cls;return x;};
const pct=n=>Number.isFinite(n)?(n*100).toFixed(1)+'%':'—';
const tm=n=>Number.isFinite(n)?n.toFixed(2):'—';
const policyNames={sequential:'Sequential',replay:'Replay',guard:'Risk-gated'};
const labels={compiled:'Compiled',compile_error:'Compiler rejected',invalid_output:'Format rejected',compile_timeout:'Compiler timed out',pass:'Behavior tests passed',test_failure:'Behavior tests failed'};
let ledger=[];
try{ledger=JSON.parse(localStorage.getItem('celestica-evidence-v1')??'[]').filter(r=>r?.lab).slice(0,80);}catch{}
function record(lab,mode,proposal,measurement,contract,decision,resources,provenance){
 ledger.unshift({lab,mode,proposal,measurement,contract,decision,resources,provenance,at:new Date().toISOString()});ledger=ledger.slice(0,80);
 try{localStorage.setItem('celestica-evidence-v1',JSON.stringify(ledger));}catch{}
 renderLedger();
}
function renderLedger(){
 const filter=$('record-filter').value, rows=ledger.filter(r=>filter==='all'||r.lab===filter);
 const pane=$('record-list');pane.replaceChildren();
 if(!rows.length){pane.append(node('p','Run a lab to add its evidence to this ledger.'));return;}
 for(const row of rows.slice(0,20)){
  const detail=node('details');
  detail.append(node('summary',`${row.lab} · ${row.mode} · ${row.decision}`),node('pre',JSON.stringify(row,null,2)));
  pane.append(detail);
 }
}
function download(name,value){
 const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'})), a=node('a');
 a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),300);
}
function meter(name,val,caption,alt=false){
 const item=node('div',undefined,'bar-meter'), heading=node('header'), rail=node('div',undefined,'rail'), fill=node('span');
 heading.append(node('span',name),node('strong',caption));
 fill.style.width=(Math.max(0,Math.min(1,val||0))*100)+'%';if(alt)fill.className='alt';
 rail.append(fill);item.append(heading,rail);return item;
}
function table(head,rows){
 const div=node('div',undefined,'table-wrap'), t=node('table'), h=node('thead'), a=node('tr'), b=node('tbody');
 head.forEach(x=>a.append(node('th',x)));h.append(a);
 for(const row of rows){const tr=node('tr');for(const x of row)tr.append(node('td',String(x)));b.append(tr);}
 t.append(h,b);div.append(t);return div;
}
const nextFrame=()=>new Promise(resolve=>requestAnimationFrame(resolve));
function network(mode){
 $('network').children[0].textContent=mode==='digits'?'64 pixel inputs':'9 model inputs';
 $('network').children[2].textContent=mode==='digits'?'10 digit logits':'2 feasibility logits';
}
function showMemory(stats){
 $('mem-bars').replaceChildren(...POLICIES.map(k=>meter(policyNames[k],stats[k].retention,pct(stats[k].retention),k==='guard')));
 $('mem-table').replaceChildren(table(['Policy','Final task','Mean forgetting','Risk AP / rate','Extra gradient examples'],
  POLICIES.map(k=>[policyNames[k],pct(stats[k].newAccuracy),pct(stats[k].forgetting),
       `${tm(stats[k].AP)} / ${tm(stats[k].prevalence)}`,Math.round(stats[k].counts.monitorBackpropExamples)])));
}
function recordedMemory(log=true){
 const mode=$('mem-mode').value, stats=evidence.memory[mode].stats;
 network(mode);showMemory(stats);put('mem-status','Recorded local experiment · five paired seeds · 44 training batches per task.');
 const gap=100*(stats.guard.retention-stats.replay.retention);
 put('mem-insight',`Replay retained ${pct(stats.replay.retention)}. The guard changed retention by ${gap.toFixed(1)} points versus replay and reached ${pct(stats.guard.newAccuracy)} on the final task. The paired result does not establish a governance advantage.`);
 if(log)record('Memory','recorded',mode,stats,'Separate train, replay, monitor, risk and test sets','Retain replay comparator',{seeds:5,batch:24},'evidence/benchmark.json');
}
$('memory-run').onclick=async()=>{
 const mode=$('mem-mode').value, seed=Number($('mem-seed').value);
 if(!Number.isInteger(seed)||seed<1||seed>999999){put('mem-status','Enter a whole-number seed from 1 to 999999.');return;}
 const controls=['memory-run','memory-replay','mem-mode','mem-seed'].map($);
 controls.forEach(x=>x.disabled=true);network(mode);
 const runs={};
 try{
  for(const policy of POLICIES){
   const generator=train({mode,policy,seed});
   let result;
   while(!(result=generator.next()).done){
    const r=result.value;
    put('mem-status',`Live training · ${policyNames[policy]} · task ${r.task}, batch ${r.step}/${r.steps}`);
    if(r.cosine!==null&&r.cosine!==undefined){
     $('gradient-marker').style.left=(50+50*r.cosine)+'%';
     put('gradient-label',`cosine ${tm(r.cosine)} · forecast Δloss ${tm(r.projected)}`);
     put('guard-memo',`${r.predicted?'Potential increase in old loss.':'No threshold crossing predicted.'} Guard corrections: ${r.counts.guardCorrections}. Rejected updates: ${r.counts.guardRejected}.`);
    }
    if(r.accuracy)put('mem-status',`Live · ${policyNames[policy]} · task ${r.task} evaluation: ${r.accuracy.map(pct).join(' / ')}`);
    await nextFrame();
   }
   runs[policy]=result.value;
  }
  showMemory(runs);put('mem-status',`Live · seed ${seed} · ${runs.replay.architecture.join(' → ')} · ${runs.replay.parameters} trained parameters per network.`);
  put('mem-insight',`Final earlier-task accuracy in your experiment: ${pct(runs.sequential.retention)} sequential, ${pct(runs.replay.retention)} replay and ${pct(runs.guard.retention)} risk-gated.`);
  const summary=Object.fromEntries(POLICIES.map(k=>{const {diagnostics,...row}=runs[k];return [k,row];}));
  record('Memory','live',`${mode} / seed ${seed}`,summary,'Hold final test split out of training and control','Compare retention and acquisition',
   Object.fromEntries(POLICIES.map(k=>[k,runs[k].counts])),'lab/memory.mjs');
 }finally{controls.forEach(x=>x.disabled=false);}
};
$('memory-replay').onclick=()=>recordedMemory();
$('mem-mode').onchange=()=>recordedMemory(false);
recordedMemory(false);

const inputs=[['altitude','Altitude',350,950,10,'km'],['beta','Sun–orbit angle',0,75,1,'°'],['load','Electrical load',12,70,1,'W'],['ceiling','Mass ceiling',10,22,.2,'kg'],['solarLoss','Solar loss',0,65,1,'%'],['batteryLoss','Battery loss',0,60,1,'%'],['extraEclipse','Extra eclipse',0,20,1,'min']];
const c={...DEFAULT};let current=fixed,result, online=false, request=0;
for(const [k,name,min,max,step,unit] of inputs){
 const cell=node('div',undefined,'input'), lab=node('label',name), value=node('output'), slide=node('input');
 slide.id='arg-'+k;slide.type='range';slide.min=min;slide.max=max;slide.step=step;
 slide.value=c[k]*(unit==='%'?100:1);lab.htmlFor=slide.id;value.textContent=slide.value+' '+unit;lab.append(value);
 slide.oninput=()=>{c[k]=Number(slide.value)/(unit==='%'?100:1);value.textContent=slide.value+' '+unit;request++;updateAxiom();};
 cell.append(lab,slide);$('mission-inputs').append(cell);
}
function graphicCharges(){
 const canvas=$('charge'), W=canvas.clientWidth,H=canvas.clientHeight;
 if(!W||!H||!result)return;
 const scale=Math.min(devicePixelRatio,2);canvas.width=W*scale;canvas.height=H*scale;
 const ctx=canvas.getContext('2d');ctx.scale(scale,scale);
 const left=50,right=W-14,top=18,bottom=H-30,y=x=>bottom-(bottom-top)*x;
 const vals=result.events, max=Math.max(result.full,1), min=Math.min(0,result.minimum), r=max-min;
 const yPoint=wh=>y((wh-min)/r);
 ctx.font='11px system-ui';ctx.fillStyle='#425773';ctx.fillText(max.toFixed(0)+' Wh',4,top+4);ctx.fillText(min.toFixed(0)+' Wh',4,bottom+4);
 ctx.strokeStyle='#b9c9dc';ctx.beginPath();ctx.moveTo(left,top);ctx.lineTo(left,bottom);ctx.lineTo(right,bottom);ctx.stroke();
 ctx.strokeStyle='#a22c2c';ctx.setLineDash([5,4]);ctx.beginPath();ctx.moveTo(left,yPoint(result.reserve));ctx.lineTo(right,yPoint(result.reserve));ctx.stroke();ctx.setLineDash([]);
 let hours=0;ctx.beginPath();ctx.moveTo(left,yPoint(result.full));
 for(const v of vals){hours+=v.duration;ctx.lineTo(left+(right-left)*hours/(2*result.period),yPoint(v.wh));}
 ctx.strokeStyle='#1452ca';ctx.lineWidth=2.5;ctx.stroke();
 ctx.fillStyle='#425773';ctx.fillText('0',left,bottom+17);ctx.fillText(Math.round(120*result.period)+' min',Math.max(left,right-42),bottom+17);
}
function updateAxiom(prefix=''){
 result=verify(c,current,true);
 const checks=table(['Hard constraint','Margin','Decision'],result.checks.map(x=>[x.name,`${tm(x.margin)} ${x.unit}`,x.pass?'PASS':'FAIL']));
 for(const row of checks.querySelectorAll('tbody tr'))row.children[2].className=row.children[2].textContent==='PASS'?'pass':'fail';
 $('axiom-checks').replaceChildren(checks);
 put('axiom-status',`${prefix}${current.id} · ${tm(result.mass)} kg · ${Math.round(result.eclipse*60)} min eclipse · ${result.pass?'verified in this model':'constraint failure'}`);
 graphicCharges();
}
function axiomRecord(description,extra={}){
 record('Axiom','live calculation',description,{design:current.id,mission:{...c},checks:result.checks,...extra},
  'All four margins must be non-negative',result.pass?'Accept in model':'Reject in model',{orbits:4},'lab/axiom.mjs');
}
$('axiom-failure').onclick=()=>{
 const s=$('arg-solarLoss');s.value='48';s.dispatchEvent(new Event('input'));
 updateAxiom('Solar output reduced by 48%. ');axiomRecord('Injected solar loss');
};
$('axiom-redesign').onclick=async()=>{
 const stamp=++request, choice=solve(c);
 if(!choice.design){
  updateAxiom('No feasible catalog pair. ');
  record('Axiom','live calculation','Minimum-mass redesign',{design:null,mission:{...c}},'Four hard margins','Reject all catalog pairs',
    {considered:choice.considered},'lab/axiom.mjs');
  return;
 }
 current=choice.design;updateAxiom('Minimum-mass verified catalog pair. ');axiomRecord('Minimum-mass redesign',{screened:choice.passedScreen});
 if(location.protocol!=='file:'){
  try{
   const v=await post('/api/axiom/check',result.checks,3500);
   if(stamp===request&&v.checks.every(x=>x.status==='PASS'))put('axiom-mode','Physics + AxiomForge cross-check');
  }catch{}
 }
};
$('axiom-ai').onclick=async()=>{
 if(!online){put('axiom-status','Local AI unavailable. The offline optimizer remains available.');return;}
 const stamp=++request,o=orbit(c);
 put('axiom-status','Local model is proposing a solar array and battery…');
 try{
  const x=await post('/api/axiom/propose',{load:c.load,day:o.day,eclipse:o.eclipse,solarLoss:c.solarLoss,batteryLoss:c.batteryLoss,ceiling:c.ceiling},85000);
  if(stamp!==request)return;
  const proposed=x.design&&catalog.find(v=>v.panel.id===x.design.solar&&v.battery.id===x.design.battery);
  if(!proposed){put('axiom-status','Model output violated the catalog format. Proposal rejected.');return;}
  current=proposed;updateAxiom('Local AI proposal. ');axiomRecord('Local AI catalog proposal',{tokens:x.tokens});
 }catch{if(stamp===request)put('axiom-status','Local AI unavailable. The offline optimizer remains available.');}
};
const pause=mountOrbit($('orbit'),()=>({result,design:current}));
$('orbit-pause').onclick=()=>{const p=pause();$('orbit-pause').setAttribute('aria-pressed',String(p));put('orbit-pause',p?'Resume orbit':'Pause orbit');};
window.addEventListener('resize',graphicCharges);updateAxiom();
const ax=evidence.axiom;
$('axiom-bench').append(meter('Fixed catalog pair',ax.fixedPass/ax.n,`${ax.fixedPass} / ${ax.n}`,true),meter('Optimized and verified',ax.solved/ax.n,`${ax.solved} / ${ax.n}`),node('p',`${ax.exact}/${ax.n} decisions matched exhaustive search. ${ax.infeasible} had no feasible catalog solution.`,'muted'));

const liveChoices=[['demo_battery','Battery underflow'],['demo_water_tank','Water-tank fill'],['demo_rainfall','Rainfall streak'],['demo_air_alert','Air alert'],['demo_sensor_average','Temperature average'],['demo_sort_samples','Stable sort']];
const simulated={id:'tie',spec:'For [7, 2, 7, 4], return the one-based position of the last maximum.',
 first:{body:'first position of max → 1',compiler:'compiled',status:'test_failure'},
 last:{body:'last position of max → 3',compiler:'compiled',status:'pass'}};
let kcRow=null,kcStamp=0;
function chooseCase(){
 kcStamp++;kcRow=null;
 const mode=$('kc-mode').value;
 $('kc-cards').hidden=true;$('kc-tests').disabled=true;$('kc-compile').disabled=false;
 put('kc-compile',mode==='live'?'Generate and compile':mode==='simulation'?'Compare the two rules':'Reveal compiler verdict');
 put('kc-status',mode==='recorded'?'Recorded model outputs from the historical Rust study.':
  mode==='simulation'?'Educational simulation. No inference or Rust compiler runs here.':online?'Local inference · model and verification run on this computer.':'Local inference server unavailable. Recorded and simulation modes work offline.');
 const choices=mode==='recorded'?archive.recorded.map(r=>[r.id,r.id.replaceAll('_',' ')]):mode==='live'?liveChoices:[['tie','Tied maximum']];
 $('kc-case').replaceChildren(...choices.map(([v,l])=>{const n=node('option',l);n.value=v;return n;}));
 describeCase();
}
function describeCase(){
 kcStamp++;kcRow=null;$('kc-cards').hidden=true;$('kc-tests').disabled=true;$('kc-compile').disabled=false;
 const mode=$('kc-mode').value;
 put('kc-spec',mode==='simulation'?simulated.spec:mode==='recorded'?archive.recorded.find(x=>x.id===$('kc-case').value)?.spec:'Choose a curated Rust challenge to start inference.');
}
function kcCard(id,row,behavior,mode){
 const pane=$(id);pane.replaceChildren();
 const status=row.compiler==='compiled';
 pane.append(node('p',mode==='simulation'?'Both rules are permitted in this exercise':labels[row.compiler]??row.compiler,status?'pass':'fail'),
  node('pre',row.body??'No valid function body'));
 if(row.diagnostic){
  const details=node('details');details.append(node('summary','Compiler feedback'),node('pre',row.diagnostic));pane.append(details);
 }
 if(behavior)pane.append(node('p',mode==='simulation'?(row.status==='pass'?'Expected position 3 · Pass':'Expected position 3 · Fail'):
  labels[row.status]??row.status,row.status==='pass'?'pass':'fail'));
}
function showKC(behavior){
 const mode=$('kc-mode').value;
 kcCard('kc-first',kcRow.first,behavior,mode);kcCard('kc-last',kcRow.last,behavior,mode);
 put('kc-first-title',mode==='simulation'?'First match':mode==='live'?'Initial response':'Original Qwen');
 put('kc-last-title',mode==='simulation'?'Last match':mode==='live'?'Selected response':'Compiler-gated route');
 $('kc-cards').hidden=false;$('kc-tests').disabled=behavior;
}
$('kc-compile').onclick=async()=>{
 const mode=$('kc-mode').value, id=$('kc-case').value, stamp=++kcStamp;
 if(mode==='simulation')kcRow=simulated;
 else if(mode==='recorded')kcRow=archive.recorded.find(r=>r.id===id);
 else{
  if(!online){put('kc-status','Local inference service unavailable. Switch to recorded experiment.');return;}
  $('kc-compile').disabled=true;put('kc-status','Generating and compiling Rust locally…');
  try{
   const v=await post('/api/kc/'+id,null,295000);
   if(stamp!==kcStamp)return;
   const map=x=>({body:x.body,compiler:x.compile,diagnostic:x.diag,status:x.functional});
   kcRow={id,first:map(v.initial),last:map(v.selected),resources:{tokens:v.tokens,calls:v.calls,seconds:v.seconds}};
   put('kc-status',`${v.model} · ${v.calls} model call(s) · ${v.tokens} tokens · ${tm(v.seconds)} seconds of generation`);
  }catch{if(stamp===kcStamp)put('kc-status','Live inference failed. Recorded experiment is available.');return;}
  finally{if(stamp===kcStamp)$('kc-compile').disabled=false;}
 }
 if(kcRow)showKC(false);
};
$('kc-tests').onclick=()=>{
 if(!kcRow)return;
 showKC(true);
 const mode=$('kc-mode').value;
 record('KC',mode,kcRow.id,{initial:kcRow.first.status,selected:kcRow.last.status},
 'Compilation and independent behavior are reported separately',kcRow.last.status==='pass'?'Accept tested behavior':'Reject or unresolved',
 kcRow.resources??{},mode==='recorded'?'evidence/kc.json':mode==='live'?'Local Qwen and isolated WASI':'Deterministic browser simulation');
};
$('kc-mode').onchange=chooseCase;$('kc-case').onchange=describeCase;chooseCase();
async function post(url,data,timeout){
 const opt={method:'POST',signal:AbortSignal.timeout(timeout)};
 if(data!==null){opt.headers={'Content-Type':'application/json'};opt.body=JSON.stringify(data);}
 const r=await fetch(url,opt);if(!r.ok)throw Error('Local service unavailable');return r.json();
}
if(location.protocol!=='file:'){
 fetch('/api/status',{signal:AbortSignal.timeout(2800)}).then(r=>r.json()).then(v=>{online=!!v.live;if($('kc-mode').value==='live')chooseCase();}).catch(()=>{});
}
const provenance=[
 ['FRI/VAC','Archived digit research includes output-margin risk prediction and a negative governor result. Run 10 passed 44 engineering tests, with CIFAR-100 training blocked.'],
 ['AxiomForge','Seven original local tests passed. No official PLE benchmark tasks ran in the recovered checkpoint. The orbital lab is an original simplified exhibit model.'],
 ['KC','The earlier KC adapter genuinely trained. The local 0.5B condition and historical 4B adapter are separate experimental conditions.'],
 ['Controls','The public digit dataset has fixed role-disjoint splits. Engineering cases are seeded synthetic scenarios. Offline mode needs no model download.']
];
for(const [a,b] of provenance){const card=node('article',undefined,'frame');card.append(node('h3',a),node('p',b,'muted'));$('provenance').append(card);}
$('presentation').onclick=()=>{const enabled=document.body.classList.toggle('present');$('presentation').setAttribute('aria-pressed',String(enabled));if(enabled)location.hash='memory';};
$('export-records').onclick=()=>download('celestica_experiment_records.json',ledger);
$('record-filter').onchange=renderLedger;
renderLedger();
