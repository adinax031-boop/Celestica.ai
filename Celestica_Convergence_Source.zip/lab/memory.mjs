import {pixels,labels,provenance} from './digits.mjs';
import {rng,sample,verify,catalog,orbit} from './axiom.mjs';
export {provenance};
export const POLICIES=['sequential','replay','guard'];
const WIDTH=24, BATCH=24, LR=.20;
const shuffled=(values,r)=>{
 const a=values.slice();
 for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
 return a;
};
const digitSamples=pixels.map((row,i)=>({x:Float64Array.from(row,x=>parseInt(x,17)/8-1),y:+labels[i],id:i}));
function digitData(seed){
 const by=Array.from({length:10},()=>[]); for(const example of digitSamples)by[example.y].push(example);
 const make=()=>({train:[],replay:[],monitor:[],risk:[],test:[]});
 const tasks=Array.from({length:5},make);
 const s=[0,70,88,104,122,172], keys=Object.keys(make());
 by.forEach((examples,i)=>{
  const perm=shuffled(examples,rng(8177+i));
  keys.forEach((k,j)=>tasks[Math.floor(i/2)][k].push(...perm.slice(s[j],s[j+1])));
 });
 return {tasks,inputs:64,outputs:10,seed};
}
function engineeringData(seed){
 const tasks=[];
 for(let t=0;t<2;t++){
  const task={};
  ['train','replay','monitor','risk','test'].forEach((split,idx)=>{
   const random=rng(8555+100*t+idx);
   task[split]=Array.from({length:[220,34,32,64,120][idx]},(_,i)=>{
    const c=sample(random,t), d=catalog[Math.floor(random()*catalog.length)], o=orbit(c);
    const values=[c.load/40-1,o.eclipse/.6-1,o.day-1,c.ceiling/15-1,d.panel.w/90-1,
       d.battery.wh/100-1,c.solarLoss*3,c.batteryLoss*3,d.panel.kg/2+d.battery.kg-1];
    return {x:Float64Array.from(values),y:+verify(c,d).pass,id:`${t}-${split}-${i}`};
   });
  });
  tasks.push(task);
 }
 return {tasks,inputs:9,outputs:2,seed};
}
const engineering=engineeringData(0);
export const dataset=(mode,seed)=>mode==='engineering'?{...engineering,seed}:digitData(seed);
function makeModel(n,m,r){
 const size=(n+1)*WIDTH+(WIDTH+1)*m;
 return {n,m,w:Float64Array.from({length:size},(_,i)=>(r()*2-1)*(i<(n+1)*WIDTH?Math.sqrt(3/n):Math.sqrt(3/WIDTH)))};
}
function forward(model,x,w=model.w){
 const {n,m}=model,a=new Float64Array(WIDTH),p=new Float64Array(m);
 const off=WIDTH*(n+1);
 for(let h=0;h<WIDTH;h++){
  const base=h*(n+1);let sum=w[base+n];
  for(let i=0;i<n;i++)sum+=w[base+i]*x[i];
  a[h]=Math.tanh(sum);
 }
 for(let k=0;k<m;k++){
  const base=off+k*(WIDTH+1);let sum=w[base+WIDTH];
  for(let h=0;h<WIDTH;h++)sum+=w[base+h]*a[h];
  p[k]=sum;
 }
 const max=Math.max(...p);let denom=0;
 for(let k=0;k<m;k++){p[k]=Math.exp(p[k]-max);denom+=p[k];}
 for(let k=0;k<m;k++)p[k]/=denom;
 return {p,a};
}
function gradient(model,data){
 const {w,n,m}=model,g=new Float64Array(w.length),off=WIDTH*(n+1);
 for(const {x,y} of data){
  const {p,a}=forward(model,x);
  const hidden=new Float64Array(WIDTH);
  for(let k=0;k<m;k++){
   const err=p[k]-(k===y?1:0), base=off+k*(WIDTH+1);
   g[base+WIDTH]+=err;
   for(let h=0;h<WIDTH;h++){g[base+h]+=err*a[h];hidden[h]+=w[base+h]*err;}
  }
  for(let h=0;h<WIDTH;h++){
   const e=hidden[h]*(1-a[h]*a[h]),base=h*(n+1);
   for(let i=0;i<n;i++)g[base+i]+=e*x[i];
   g[base+n]+=e;
  }
 }
 return g.map(x=>x/data.length);
}
function measure(model,data,w=model.w){
 let loss=0,correct=0;
 for(const row of data){
  const {p}=forward(model,row.x,w);
  correct+=+(p.indexOf(Math.max(...p))===row.y);
  loss-=Math.log(Math.max(1e-15,p[row.y]));
 }
 return {loss:loss/data.length,acc:correct/data.length};
}
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const advance=(w,g)=>w.map((x,i)=>x-LR*g[i]);
function pick(pool,n,r){return Array.from({length:n},()=>pool[Math.floor(r()*pool.length)]);}
const riskThreshold=.007;
export function averagePrecision(pairs){
 const positives=pairs.filter(r=>r.positive).length;
 if(!positives)return null;
 const sorted=pairs.slice().sort((a,b)=>b.score-a.score);
 let ap=0,seen=0,tp=0;
 for(let i=0;i<sorted.length;){
  let end=i,hits=0;
  while(end<sorted.length&&sorted[end].score===sorted[i].score){hits+=+sorted[end].positive;end++;}
  tp+=hits;seen+=end-i;ap+=hits/positives*tp/seen;i=end;
 }
 return ap;
}
export function* train({mode='digits',policy='replay',seed=917,steps=44}={}){
 if(!POLICIES.includes(policy)||!['digits','engineering'].includes(mode)||!Number.isInteger(seed)||!Number.isInteger(steps)||steps<1||steps>120)throw Error('Invalid experiment configuration');
 const {tasks,inputs,outputs}=dataset(mode,seed);
 const m=makeModel(inputs,outputs,rng(seed+1)), rand=rng(seed+2), replayRng=rng(seed+3), monitorRng=rng(seed+4);
 const risk=[],metrics=[],counts={updates:0,trainingExamples:0,replayExamples:0,monitorBackpropExamples:0,diagnosticForwardExamples:0,guardCorrections:0,guardRejected:0};
 const acquired=[], t0=performance.now();
 for(let t=0;t<tasks.length;t++){
  const oldReplay=tasks.slice(0,t).flatMap(x=>x.replay), monitor=tasks.slice(0,t).flatMap(x=>x.monitor),
   oldRisk=tasks.slice(0,t).flatMap(x=>x.risk), current=tasks[t].train;
  for(let i=0;i<steps;i++){
   const fresh=pick(current,BATCH,rand);
   const instrument=t>0&&i%4===0;
   const diagnostic=(t>0&&policy==='guard')||instrument;
   const memory= t>0&&policy!=='sequential'?pick(oldReplay,8,replayRng):[];
   const reference=diagnostic?pick(monitor,16,monitorRng):[];
   const currentGradient=diagnostic?gradient(m,fresh):null;
   const oldGradient=diagnostic?gradient(m,reference):null;
   counts.monitorBackpropExamples+=reference.length+(diagnostic?BATCH:0);
   const dotProduct=diagnostic?dot(currentGradient,oldGradient):null;
   const projected=diagnostic?-LR*dotProduct:null;
   const cosine=diagnostic?dotProduct/(Math.sqrt(dot(currentGradient,currentGradient)*dot(oldGradient,oldGradient))||1):null;
   const predicted=projected!==null&&projected>riskThreshold;
   if(instrument){
    const actual=measure(m,oldRisk,advance(m.w,currentGradient)).loss-measure(m,oldRisk).loss;
    counts.diagnosticForwardExamples+=2*oldRisk.length;
    risk.push({score:projected,positive:actual>riskThreshold,actual,cosine,task:t+1,step:i+1});
   }
   const useReplay=memory.length>0&&(policy==='replay'||predicted);
   const batch=useReplay?fresh.slice(0,16).concat(memory):fresh;
   const proposed=advance(m.w,gradient(m,batch));
   counts.trainingExamples+=batch.length;counts.replayExamples+=useReplay?8:0;
   if(policy==='guard'&&predicted){
    counts.guardCorrections++;
    const before=measure(m,reference), after=measure(m,reference,proposed);
    counts.diagnosticForwardExamples+=2*reference.length;
    if(after.loss>before.loss+.025) counts.guardRejected++;
    else m.w=proposed;
   }else m.w=proposed;
   counts.updates++;
   if(i%6===0||i===steps-1)yield {task:t+1,step:i+1,steps,cosine,projected,predicted,counts:{...counts}};
  }
  const row=tasks.slice(0,t+1).map(x=>measure(m,x.test).acc);
  acquired.push(row[t]);metrics.push(row);
  yield {task:t+1,step:steps,steps,accuracy:row,counts:{...counts}};
 }
 const final=metrics.at(-1);
 const mean=a=>a.reduce((x,y)=>x+y,0)/a.length;
 return {mode,policy,seed,steps,counts,acquired,metrics,
  retention:mean(final.slice(0,-1)),newAccuracy:final.at(-1),
  forgetting:mean(acquired.slice(0,-1).map((v,i)=>v-final[i])),
  averageAcquisition:mean(acquired), AP:averagePrecision(risk),prevalence:risk.length?risk.filter(r=>r.positive).length/risk.length:0,
  diagnostics:risk,wallMs:performance.now()-t0,
  architecture:[inputs,WIDTH,outputs],parameters:m.w.length};
}
export function finish(options){
 const it=train(options);
 let z;
 do{z=it.next();}while(!z.done);
 return z.value;
}
