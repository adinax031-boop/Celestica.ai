const earth='#dae8fa', ink='#102342', blue='#205be3';
const cube=[[-1,-1,-1],[-1,-1,1],[-1,1,-1],[-1,1,1],[1,-1,-1],[1,-1,1],[1,1,-1],[1,1,1]];
const faces=[[0,2,3,1],[4,5,7,6],[0,1,5,4],[2,6,7,3],[0,4,6,2],[1,3,7,5]];
export function mountOrbit(canvas,read){
 const ctx=canvas.getContext('2d');let yaw=.45,pitch=.37,down=null,phase=0,paused=false,stamp=0;
 const draw=(now)=>{
  requestAnimationFrame(draw);
  if(!canvas.isConnected||!canvas.clientWidth)return;
  const elapsed=stamp?Math.min(40,now-stamp):0;stamp=now;
  if(!paused)phase=(phase+elapsed/22000)%1;
  const W=canvas.clientWidth,H=canvas.clientHeight,scale=Math.min(W,H)*.255,d=Math.min(devicePixelRatio,2);
  if(canvas.width!==Math.round(W*d)||canvas.height!==Math.round(H*d)){canvas.width=Math.round(W*d);canvas.height=Math.round(H*d);}
  ctx.setTransform(d,0,0,d,0,0);ctx.clearRect(0,0,W,H);
  const cx=.52*W,cy=.53*H;
  const rotate=([x,y,z])=>{
   const X=x*Math.cos(yaw)+z*Math.sin(yaw),Z=-x*Math.sin(yaw)+z*Math.cos(yaw);
   return [X,y*Math.cos(pitch)-Z*Math.sin(pitch),y*Math.sin(pitch)+Z*Math.cos(pitch)];
  };
  const view=v=>{const [x,y,z]=rotate(v);const f=1/(1-z*.095);return [cx+x*scale*f,cy-y*scale*f,z];};
  function path(vals,color,width=1,fill=false){
   ctx.beginPath();vals.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));
   if(fill){ctx.closePath();ctx.fillStyle=color;ctx.fill();}
   else{ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();}
  }
  const orb=a=>[1.64*Math.cos(a),0,1.64*Math.sin(a)];
  const {result,design}=read();
  const horizon=result?result.eclipse/result.period:0;
  const a=phase*2*Math.PI-Math.PI*horizon;
  const segments=Array.from({length:90},(_,i)=>{
   const angle=i/90*2*Math.PI;
   return {points:[view(orb(angle)),view(orb(angle+2*Math.PI/90))],shadow:Math.abs(Math.atan2(Math.sin(angle),Math.cos(angle)))<=Math.PI*horizon};
  });
  for(const seg of segments.filter(v=>v.points[0][2]<0))path(seg.points,seg.shadow?'#262d3e':'#a2b9e7',seg.shadow?3:1.5);
  ctx.beginPath();ctx.arc(cx,cy,scale*.9,0,2*Math.PI);ctx.fillStyle=earth;ctx.fill();
  ctx.save();ctx.clip();
  // Planet grid projects actual latitude and longitude onto the same 3D coordinate system.
  for(let ring=0;ring<11;ring++){
   const lo=(ring/10)*Math.PI;
   const pts=Array.from({length:70},(_,j)=>{const f=j/69*2*Math.PI;return view([.88*Math.cos(f)*Math.cos(lo),.88*Math.sin(f),.88*Math.cos(f)*Math.sin(lo)]);});
   path(pts.filter(v=>v[2]>=0),'#a2b9dd');
  }
  for(let y=-.6;y<=.61;y+=.2){
   const rad=Math.sqrt(.88**2-y**2);
   const pts=Array.from({length:100},(_,j)=>view([rad*Math.cos(j/99*2*Math.PI),y,rad*Math.sin(j/99*2*Math.PI)]));
   path(pts.filter(v=>v[2]>=0),'#a2b9dd');
  }
  ctx.restore();
  for(const seg of segments.filter(v=>v.points[0][2]>=0))path(seg.points,seg.shadow?'#262d3e':'#4778d8',seg.shadow?3:1.5);
  const [sx,sy,sz]=orb(a),body=cube.map(([x,y,z])=>view([sx+x*.1,sy+y*.14,sz+z*.1]));
  const satellite=view([sx,sy,sz]);
  if(satellite[2]>=0||Math.hypot(satellite[0]-cx,satellite[1]-cy)>scale*.92){
   const color=['#10232d','#5878a4','#2f4359','#7799cb','#3364b2','#5476a0'];
   const span=.25+(design?.panel.id??4)*.035;
   for(const sign of [1,-1]){
    const solarPoints=[[.12,-.065],[span,-.065],[span,.065],[.12,.065]].map(([x,z])=>view([sx+x*sign,sy,sz+z]));
    path([...solarPoints,solarPoints[0]],blue,1,true);path([...solarPoints,solarPoints[0]],'#0b2d7e',1);
    for(let t=.16;t<span;t+=.058)path([view([sx+t*sign,sy,sz-.065]),view([sx+t*sign,sy,sz+.065])],'#a5c8ff',.7);
   }
   faces.map((f,i)=>[i,f.reduce((sum,j)=>sum+body[j][2],0)]).sort((x,y)=>x[1]-y[1]).forEach(([i])=>path(faces[i].map(j=>body[j]),color[i],1,true));
  }
  ctx.font='600 12px system-ui';ctx.fillStyle=ink;
  ctx.fillText('CIRCULAR ORBIT · SCHEMATIC',15,24);
  ctx.fillStyle=blue;ctx.fillText(Math.abs(Math.atan2(Math.sin(a),Math.cos(a)))<=Math.PI*horizon?'● IN ECLIPSE':'● IN SUNLIGHT',15,H-17);
 };
 canvas.onpointerdown=e=>{down=[e.clientX,e.clientY];canvas.setPointerCapture(e.pointerId);};
 canvas.onpointermove=e=>{if(down){yaw+=(e.clientX-down[0])*.009;pitch=Math.max(-1.4,Math.min(1.4,pitch+(e.clientY-down[1])*.009));down=[e.clientX,e.clientY];}};
 canvas.onpointerup=canvas.onpointercancel=()=>down=null;
 canvas.onkeydown=e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){yaw+=e.key==='ArrowLeft'?-.15:.15;e.preventDefault();}if(e.key==='ArrowUp'||e.key==='ArrowDown'){pitch=Math.max(-1.4,Math.min(1.4,pitch+(e.key==='ArrowUp'?.15:-.15)));e.preventDefault();}};
 requestAnimationFrame(draw);
 return ()=>{paused=!paused;return paused;};
}
