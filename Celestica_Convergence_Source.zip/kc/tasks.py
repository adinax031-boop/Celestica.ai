"""Original Rust specs, reference bodies and independent behavioral tests."""
from dataclasses import dataclass, asdict
import re

@dataclass(frozen=True)
class Task:
    id: str
    family: str
    difficulty: str
    spec: str
    sig: str
    body: str
    checks: str
    broken: str = ""
    prelude: str = ""
    suite: str = "authored"
    source: str = "Celestica Mission 01"
    license: str = "MIT"
    harness: str = ""

    def prompt(self):
        repair = (
            "\nCurrent, broken body:\n```rust\n" + self.broken + "\n```"
            if self.broken else ""
        )
        prelude = "\nAvailable declarations:\n" + self.prelude if self.prelude else ""
        return (
            "Write only the Rust statements inside the specified function body. "
            "Return one fenced rust code block. Do not repeat the signature. "
            "Use the Rust standard library only.\n" + self.spec + prelude +
            "\nSignature: " + self.sig + repair
        )

# Rows use distinct named operations. Train/validation/test split by operation, not textual variants.
_RAW = [
("train","ownership","easy","duplicate_owned","Return two owned copies of the input string.",
"(s: String) -> (String, String)","(s.clone(), s)",'assert_eq!(@("ab".into()), ("ab".into(),"ab".into())); assert_eq!(@(String::new()), (String::new(),String::new()));',"(s, s)"),
("train","borrowing","easy","push_text","Append suffix to the existing String in place.",
"(dst: &mut String, suffix: &str)","dst.push_str(suffix);",'let mut s="no".to_string(); @(&mut s,"on"); assert_eq!(s,"noon"); @(&mut s,""); assert_eq!(s,"noon");',"dst.push(suffix);"),
("train","lifetimes","medium","first_piece","Return the first comma-separated field borrowing from input. Leading commas give an empty result.",
"<'a>(s: &'a str) -> &'a str","s.split(',').next().unwrap_or(\"\")",'assert_eq!(@("abc,def"),"abc"); assert_eq!(@(",def"),""); assert_eq!(@("é"),"é");'),
("train","lifetimes","medium","first_or_other","Return the first nonempty string, preferring a. Both results borrow from the original inputs.",
"<'a>(a: &'a str, b: &'a str) -> &'a str","if a.is_empty() { b } else { a }",'assert_eq!(@("x","y"),"x"); assert_eq!(@("","y"),"y"); assert_eq!(@("",""),"");'),
("train","generics","easy","copy_first","Return a clone of the first item, or None if empty.",
"<T: Clone>(items: &[T]) -> Option<T>","items.first().cloned()",'assert_eq!(@(&[String::from("a"),String::from("b")]),Some(String::from("a"))); assert_eq!(@::<i32>(&[]),None);',"items.first()"),
("train","generics","medium","find_larger","Return a reference to the larger value. Prefer the first argument on ties.",
"<'a, T: Ord>(a: &'a T, b: &'a T) -> &'a T","if a >= b { a } else { b }",'assert_eq!(@(&3,&5),&5); assert_eq!(@(&6,&1),&6); let a=3; let b=3; assert!(std::ptr::eq(@(&a,&b), &a));'),
("train","generics","medium","sorted_unique","Sort the vector in ascending order and remove duplicates.",
"<T: Ord>(mut values: Vec<T>) -> Vec<T>","values.sort(); values.dedup(); values",'assert_eq!(@(vec![3,1,3,2]),vec![1,2,3]); assert_eq!(@(Vec::<i32>::new()),vec![]); assert_eq!(@(vec!["z","a","a"]),vec!["a","z"]);'),
("train","errors","easy","parse_port","Parse an unpadded decimal u16. Return the parse error on invalid or out-of-range input.",
"(s: &str) -> Result<u16, std::num::ParseIntError>","s.parse::<u16>()",'assert_eq!(@("8080").unwrap(),8080); assert_eq!(@("65535").unwrap(),65535); assert!(@("65536").is_err()); assert!(@(" 42").is_err());'),
("train","errors","easy","safe_remainder","Return integer remainder. Return None for zero divisor or signed overflow.",
"(a: i32, b: i32) -> Option<i32>","a.checked_rem(b)",'assert_eq!(@(19,4),Some(3)); assert_eq!(@(-19,4),Some(-3)); assert_eq!(@(-4,0),None); assert_eq!(@(i32::MIN,-1),None);',"Some(a % b)"),
("train","errors","medium","map_parse","Parse every trimmed CSV field into i32, returning the first parse error.",
"(s: &str) -> Result<Vec<i32>, std::num::ParseIntError>","s.split(',').map(|v| v.trim().parse::<i32>()).collect()",'assert_eq!(@(" 2,-7, 9 ").unwrap(),vec![2,-7,9]); assert!(@("1,,2").is_err()); assert!(@("").is_err());'),
("train","collections","easy","frequency","Count each input integer and return a sorted map of value to number of occurrences.",
"(items: &[i32]) -> std::collections::BTreeMap<i32, usize>","let mut counts = std::collections::BTreeMap::new(); for &x in items { *counts.entry(x).or_insert(0) += 1; } counts",'assert_eq!(@(&[2,1,2]).into_iter().collect::<Vec<_>>(),vec![(1,1),(2,2)]); assert!(@(&[]).is_empty());'),
("train","collections","medium","unique_stable","Return one copy of each integer in first-occurrence order.",
"(items: &[i32]) -> Vec<i32>","let mut seen = std::collections::HashSet::new(); items.iter().copied().filter(|x| seen.insert(*x)).collect()",'assert_eq!(@(&[3,3,1,2,1]),vec![3,1,2]); assert_eq!(@(&[]),vec![]);'),
("train","collections","medium","stack_peek","Return a shared reference to the last item of the stack, if any.",
"<T>(stack: &[T]) -> Option<&T>","stack.last()",'assert_eq!(@(&[4,6,8]),Some(&8)); assert_eq!(@::<u8>(&[]),None);',"stack.first()"),
("train","collections","medium","bag_intersection","Return the multiset intersection, ordered as in a. Consume at most the multiplicity of each value in b.",
"(a: &[i32], b: &[i32]) -> Vec<i32>","let mut counts=std::collections::HashMap::new(); for &x in b { *counts.entry(x).or_insert(0usize)+=1; } a.iter().copied().filter(|x| match counts.get_mut(x) { Some(n) if *n>0 => { *n-=1; true }, _=>false }).collect()",'assert_eq!(@(&[2,1,2,2,3],&[2,3,2]),vec![2,2,3]); assert_eq!(@(&[1],&[]),vec![]);'),
("train","algorithms","medium","first_at_least","For a sorted ascending slice, return the first index with value >= target, or len if absent.",
"(xs: &[i32], target: i32) -> usize","xs.partition_point(|x| *x < target)",'assert_eq!(@(&[1,2,2,5],2),1); assert_eq!(@(&[1,2,2,5],6),4); assert_eq!(@(&[],0),0);',"xs.partition_point(|x| *x <= target)"),
("train","algorithms","medium","max_rise","Return the largest positive increase between consecutive values or zero when there is none. Inputs fit i32, but differences may not.",
"(xs: &[i32]) -> i64","xs.windows(2).map(|w| i64::from(w[1])-i64::from(w[0])).max().unwrap_or(0).max(0)",'assert_eq!(@(&[6,2,5,1,7]),6); assert_eq!(@(&[8,3]),0); assert_eq!(@(&[i32::MIN,i32::MAX]),4294967295); assert_eq!(@(&[]),0);'),
("train","algorithms","medium","remove_runs","Collapse consecutive equal values, preserving order and repetitions on nonadjacent runs.",
"(mut xs: Vec<i32>) -> Vec<i32>","xs.dedup(); xs",'assert_eq!(@(vec![3,3,2,3,3]),vec![3,2,3]); assert_eq!(@(vec![]),vec![]);'),
("train","text","easy","reverse_scalars","Reverse Unicode scalar values (not graphemes).",
"(s: &str) -> String","s.chars().rev().collect()",'assert_eq!(@("é🦀a"),"a🦀é"); assert_eq!(@(""),"");'),
("train","text","medium","unicode_prefix","Return the prefix containing at most max Unicode scalar values, borrowed from the input.",
"(s: &str, max: usize) -> &str","s.char_indices().nth(max).map_or(s, |(i, _)| &s[..i])",'assert_eq!(@("é🦀a",2),"é🦀"); assert_eq!(@("é",0),""); assert_eq!(@("a",9),"a");',"&s[..s.len().min(max)]"),
("train","numeric","easy","sum_wide","Sum input i32 values using i64 accumulation.",
"(xs: &[i32]) -> i64","xs.iter().map(|&x| i64::from(x)).sum()",'assert_eq!(@(&[i32::MAX,1]),2147483648); assert_eq!(@(&[-2,7]),5); assert_eq!(@(&[]),0);'),
("train","numeric","medium","square_checked","Return the square of n, or None if it exceeds u64.",
"(n: u64) -> Option<u64>","n.checked_mul(n)",'assert_eq!(@(12),Some(144)); assert_eq!(@(u64::MAX),None); assert_eq!(@(0),Some(0));'),
("train","mutability","easy","bump_all","Increment each value in place with saturating signed arithmetic.",
"(xs: &mut [i32])","for value in xs { *value = value.saturating_add(1); }",'let mut xs=[0,-3,i32::MAX]; @(&mut xs); assert_eq!(xs,[1,-2,i32::MAX]); @(&mut []);',"for value in xs { *value += 1; }"),
("train","mutability","medium","take_once","Return the previous value and leave the caller's Option as None.",
"<T>(slot: &mut Option<T>) -> Option<T>","slot.take()",'let mut v=Some(String::from("x")); assert_eq!(@(&mut v),Some(String::from("x"))); assert!(v.is_none()); assert_eq!(@(&mut v),None);'),
("train","memory","easy","byte_at","Read one byte by index with no panic if it is out of bounds.",
"(bytes: &[u8], idx: usize) -> Option<u8>","bytes.get(idx).copied()",'assert_eq!(@(&[4,5,6],1),Some(5)); assert_eq!(@(&[],0),None); assert_eq!(@(&[8],usize::MAX),None);',"Some(bytes[idx])"),
("train","traits","medium","show_joined","Use each item’s Display implementation. Join results with / and no trailing separator.",
"<T: std::fmt::Display>(items: &[T]) -> String","items.iter().map(ToString::to_string).collect::<Vec<_>>().join(\"/\")",'assert_eq!(@(&[1,2,3]),"1/2/3"); assert_eq!(@::<i32>(&[]),""); assert_eq!(@(&["a","b"]),"a/b");'),
("train","ownership","medium","into_names","Consume the pairs and return their owned string fields in the same order.",
"(pairs: Vec<(u8, String)>) -> Vec<String>","pairs.into_iter().map(|(_, name)| name).collect()",'assert_eq!(@(vec![(4,"z".into()),(1,"a".into())]),vec![String::from("z"),String::from("a")]); assert_eq!(@(vec![]),vec![]);'),
("train","iterators","medium","even_positions","Return the zero-based positions of even values.",
"(xs: &[i32]) -> Vec<usize>","xs.iter().enumerate().filter_map(|(i,&x)| (x%2==0).then_some(i)).collect()",'assert_eq!(@(&[-2,10,3,0]),vec![0,1,3]); assert_eq!(@(&[1,3]),vec![]);'),
("train","iterators","medium","dot_truncated","Multiply corresponding i16 inputs and sum in i64. Drop unpaired trailing values.",
"(a: &[i16], b: &[i16]) -> i64","a.iter().zip(b).map(|(&x,&y)| i64::from(x)*i64::from(y)).sum()",'assert_eq!(@(&[2,3,4],&[5,6]),28); assert_eq!(@(&[],&[4]),0); assert_eq!(@(&[-3],&[7]),-21);'),
("validation","text","easy","trailing_field","Borrow the final pipe-separated field. A trailing pipe means empty field.",
"(s: &str) -> &str","s.rsplit('|').next().unwrap_or(\"\")",'assert_eq!(@("a|b"),"b"); assert_eq!(@("a|"),""); assert_eq!(@(""),"");'),
("validation","numeric","easy","add_checked","Return the sum of two signed integers if representable, or None.",
"(x: i32, y: i32) -> Option<i32>","x.checked_add(y)",'assert_eq!(@(-2,6),Some(4)); assert_eq!(@(i32::MAX,1),None);'),
("validation","collections","easy","queue_last","Borrow the most recently inserted item from the back of the queue, or None.",
"<T>(q: &std::collections::VecDeque<T>) -> Option<&T>","q.back()",'assert_eq!(@(&std::collections::VecDeque::from([2,3])),Some(&3)); assert_eq!(@::<i32>(&std::collections::VecDeque::new()),None);'),
("test","ownership","medium","repair_shift","Return the original Vec and its length, avoiding cloning or reallocating.",
"(xs: Vec<String>) -> (Vec<String>, usize)","let len=xs.len(); (xs,len)",'let a=vec![String::from("hi")]; let ptr=a.as_ptr(); let (b,n)=@(a); assert_eq!(b,vec![String::from("hi")]); assert_eq!(b.as_ptr(),ptr); assert_eq!(n,1); assert_eq!(@(vec![]).1,0);',"(xs,xs.len())"),
("test","lifetimes","medium","before_marker","Return the part before the first marker, or the entire text if the marker is absent. Borrow only from text.",
"<'a>(text: &'a str, marker: &str) -> &'a str","text.split_once(marker).map_or(text, |(head,_)| head)",'assert_eq!(@("a🦀b🦀c","🦀"),"a"); assert_eq!(@("zzz","x"),"zzz"); assert_eq!(@("abc",""),"");'),
("test","borrowing","medium","disjoint_increment","Increment the two supplied indices exactly once each with saturating arithmetic. For duplicate indices or any out-of-bounds index, return false and leave the slice unchanged.",
"(a: &mut [i32], i: usize, j: usize) -> bool","if i==j || i>=a.len() || j>=a.len() { return false; } a[i]=a[i].saturating_add(1); a[j]=a[j].saturating_add(1); true",'let mut a=[2,9,i32::MAX]; assert!(@(&mut a,2,0)); assert_eq!(a,[3,9,i32::MAX]); assert!(!@(&mut a,0,0)); assert!(!@(&mut a,1,5)); assert_eq!(a,[3,9,i32::MAX]);'),
("test","generics","medium","last_max","Return a reference to the maximum ordered element, preferring the last on ties.",
"<T: Ord>(a: &[T]) -> Option<&T>","a.iter().max()",'let a=[1,8,3,8]; assert!(std::ptr::eq(@(&a).unwrap(),&a[3])); assert_eq!(@::<i32>(&[]),None);',"a.iter().rev().max()"),
("test","errors","medium","ascii_digit_sum","Sum ASCII digit values in a byte string. Return the index of the first invalid byte as Err. Use u64 accumulation.",
"(values: &[u8]) -> Result<u64, usize>","let mut sum=0u64; for (i,&b) in values.iter().enumerate() { if !b.is_ascii_digit() { return Err(i); } sum+=u64::from(b-b'0'); } Ok(sum)",'assert_eq!(@(b"019"),Ok(10)); assert_eq!(@(b""),Ok(0)); assert_eq!(@(b"12x7y"),Err(2)); assert_eq!(@(&[255]),Err(0));'),
("test","algorithms","medium","longest_uprun","Return the length of the longest contiguous strictly increasing run, or zero for empty input.",
"(values: &[i64]) -> usize","if values.is_empty(){return 0;} let (mut best,mut run)=(1,1); for w in values.windows(2){run=if w[0]<w[1]{run+1}else{1};best=best.max(run);} best",'assert_eq!(@(&[1,2,2,3,4,0]),3); assert_eq!(@(&[]),0); assert_eq!(@(&[7,6,5]),1); assert_eq!(@(&[7,7]),1);'),
("test","memory","medium","write_prefix","Copy as many bytes from src as fit in dst. Return the count and preserve the unfilled suffix of dst.",
"(dst: &mut [u8], src: &[u8]) -> usize","let n=dst.len().min(src.len()); dst[..n].copy_from_slice(&src[..n]); n",'let mut a=[9,8,7]; assert_eq!(@(&mut a,&[3]),1); assert_eq!(a,[3,8,7]); assert_eq!(@(&mut a,&[7,6,5,4]),3); assert_eq!(a,[7,6,5]); assert_eq!(@(&mut [],&[1]),0);',"dst.copy_from_slice(src); src.len()"),
("test","traits","medium","format_optional","Use Display for Some and return a single hyphen for None.",
"<T: std::fmt::Display>(item: Option<T>) -> String","item.map_or_else(|| \"-\".into(), |x| x.to_string())",'assert_eq!(@(Some(17)),"17"); assert_eq!(@(Some("ok")),"ok"); assert_eq!(@::<i32>(None),"-");'),
]

def authored():
    result = {"train": [], "validation": [], "test": []}
    for split, family, difficulty, name, spec, sig, body, tests, *broken in _RAW:
        result[split].append(Task(name,family,difficulty,spec,f"fn {name}{sig}",body,tests.replace("@",name),broken[0] if broken else ""))
    return result
