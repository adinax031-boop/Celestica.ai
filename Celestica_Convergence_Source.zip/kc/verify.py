"""Resource-limited, capability-free WASI Rust verifier for single-file functions."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from pathlib import Path
import hashlib
import os
import re
import shutil
import subprocess
import tempfile

from tasks import Task
from confinement import compile_rust

# Strip Rust strings, chars and comments before brace checks. Raw strings and nested
# block comments are outside this pilot's supported candidate syntax.
_LITERAL = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])\'|//[^\n]*|/\*[^*]*(?:\*(?!/)[^*]*)*\*/', re.S)
_DENIED = re.compile(
    r'\b(?:unsafe|extern|include|include_str|include_bytes|env|option_env|macro_rules|macro|'
    r'global_asm|asm|no_mangle|link|link_section|rustc|celestica_test_witness|'
    r'process|wasi|stdarch|intrinsics)\b|#\s*\!?\s*\['
)
def body_valid(body):
    if not body.strip() or len(body.encode()) > 12000 or re.search(r'\b(?:br|r)#+["\']|/\*[^*]*?/\*',body):
        return False
    # Reject compile-time inclusion even when hidden amid comments/literals.
    if re.search(r'\b(?:include(?:_str|_bytes)?|env|option_env|macro_rules|unsafe|extern)\b',body):
        return False
    code = _LITERAL.sub(" ",body)
    if _DENIED.search(code) or '"' in code:
        return False
    depth = 0
    for char in code:
        depth += (char == "{") - (char == "}")
        if depth < 0:
            return False
    return depth == 0

def source(task, body, nonce):
    return (
        '#![forbid(unsafe_code)]\n' + task.prelude + '\n' + task.harness + '\n' + task.sig + ' {\n' + body +
        '\n}\nfn main() {\n' + task.checks + '\nprintln!("celestica_test_witness:' + nonce + '");\n}\n'
    )

def verify(task, body, trusted=False):
    import wasmtime
    if not trusted and not body_valid(body):
        return "invalid_output", ""
    nonce = hashlib.sha256((task.id + task.checks).encode()).hexdigest()[:24]
    with tempfile.TemporaryDirectory(prefix="kc-wasi-") as tmp:
        temp = Path(tmp)
        (temp/"solution.rs").write_text(source(task,body,nonce))
        cmd = ["--target=wasm32-wasip1", "--edition=2021",
               "--crate-name=celestica_case", "-C", "opt-level=0", "-Awarnings",
               "solution.rs", "-o", "case.wasm"]
        try:
            proc = compile_rust(cmd, cwd=tmp)
        except subprocess.TimeoutExpired:
            return "compile_timeout", ""
        if proc.returncode:
            return "compile_error", proc.stderr[-2000:]
        config = wasmtime.Config()
        config.consume_fuel = True
        engine = wasmtime.Engine(config)
        store = wasmtime.Store(engine)
        store.set_fuel(25_000_000)
        store.set_limits(memory_size=48 * 1024**2, instances=1, memories=1)
        # No preopened host paths, inherited env, stdin, networking or process access.
        wasi = wasmtime.WasiConfig()
        wasi.stdout_file = str(temp/"out")
        store.set_wasi(wasi)
        linker = wasmtime.Linker(engine)
        linker.define_wasi()
        try:
            module = wasmtime.Module.from_file(engine, str(temp/"case.wasm"))
            instance = linker.instantiate(store,module)
            instance.exports(store)["_start"](store)
        except (wasmtime.Trap, wasmtime.WasmtimeError) as err:
            return "test_failure", str(err)[-1000:]
        expected = "celestica_test_witness:" + nonce
        lines = (temp/"out").read_text(errors="replace").splitlines()
        return ("pass","") if lines and lines[-1] == expected else ("test_failure", "Test completion marker missing")

def verify_many(pairs, trusted=False):
    with ThreadPoolExecutor(max_workers=3) as pool:
        return list(pool.map(lambda pair: verify(*pair, trusted=trusted), pairs))

def extract(text):
    text = text.rsplit("</think>",1)[-1].strip()
    match = re.fullmatch(r'```(?:rust|rs)?\s*\n(.*?)\n?```\s*', text, flags=re.S|re.I)
    return match.group(1).strip() if match else None

def smoke():
    test = Task("smoke","test","easy","return 7","fn answer() -> i32","7","assert_eq!(answer(),7);")
    result = verify_many([(test,v) for v in ["7","8",'"oops"','include!("private")','std::process::exit(0);','7 } fn x() {']])
    want = ["pass","test_failure","compile_error","invalid_output","invalid_output","invalid_output"]
    if [status for status,_ in result] != want:
        raise RuntimeError(f"WASI verifier smoke failed: {result}")
    return want
