"""Linux-only Rust compiler runner. Fail closed if isolation is unavailable."""
import ctypes as c
import errno
import os
from pathlib import Path
import signal
import subprocess
import tempfile

def restrict(fd):
    lib=c.CDLL('libseccomp.so.2')
    lib.seccomp_init.argtypes=[c.c_uint32]
    lib.seccomp_init.restype=c.c_void_p
    lib.seccomp_syscall_resolve_name.argtypes=[c.c_char_p]
    lib.seccomp_rule_add.argtypes=[c.c_void_p,c.c_uint32,c.c_int,c.c_uint]
    lib.seccomp_export_bpf.argtypes=[c.c_void_p,c.c_int]
    lib.seccomp_release.argtypes=[c.c_void_p]
    ctx=lib.seccomp_init(0x7fff0000)
    if not ctx: raise RuntimeError('seccomp unavailable')
    try:
        for name in b'socket connect bind listen accept accept4 ptrace process_vm_readv process_vm_writev mount umount2 unshare setns io_uring_setup io_uring_enter io_uring_register bpf keyctl open_by_handle_at'.split():
            num=lib.seccomp_syscall_resolve_name(name)
            if num>=0 and lib.seccomp_rule_add(ctx,0x50000|errno.EPERM,num,0):
                raise RuntimeError('seccomp rule error')
        if lib.seccomp_export_bpf(ctx,fd.fileno()): raise RuntimeError('seccomp export error')
        fd.seek(0)
    finally:
        lib.seccomp_release(ctx)

def compile_rust(args,cwd,timeout=12):
    tool=Path(os.environ.get('CELESTICA_RUST_ROOT','/opt/celestica-rust')).resolve()
    if not (tool/'bin/rustc').is_file(): raise RuntimeError('Pinned Rust toolchain missing')
    with tempfile.TemporaryFile() as filt,tempfile.TemporaryFile() as errors:
        restrict(filt)
        command=['prlimit','--cpu=9:9','--as=3221225472:3221225472','--fsize=8388608:8388608',
                 '--nofile=64:64','--core=0:0','--','bwrap','--unshare-user','--unshare-pid',
                 '--unshare-ipc','--unshare-uts','--die-with-parent','--clearenv',
                 '--setenv','PATH','/compiler/bin:/usr/bin','--setenv','LD_LIBRARY_PATH','/compiler/lib',
                 '--setenv','LC_ALL','C','--setenv','HOME','/tmp','--setenv','TMPDIR','/case',
                 '--ro-bind','/usr','/usr','--ro-bind','/lib','/lib','--ro-bind','/lib64','/lib64',
                 '--ro-bind',str(tool),'/compiler','--dev','/dev','--bind',str(Path(cwd).resolve()),'/case',
                 '--chdir','/case','--seccomp',str(filt.fileno()),'/compiler/bin/rustc',*args]
        with subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=errors,
            start_new_session=True,pass_fds=(filt.fileno(),)) as proc:
            try: proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                try: os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError: pass
                proc.wait()
                raise
        errors.seek(0)
        detail=errors.read(2**20).decode(errors='replace')
        if proc.returncode!=0 and (not detail or detail.startswith(('bwrap:','prlimit:','/compiler/bin/rustc: error while loading')) or proc.returncode<0):
            raise RuntimeError('isolation failed: '+detail[:300])
        return subprocess.CompletedProcess(command,proc.returncode,'',detail)
