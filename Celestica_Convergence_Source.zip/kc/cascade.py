"""Compiler-gated model cascade. No gold solution or evaluator verdict is accepted by the policy."""
from dataclasses import dataclass
from typing import Callable, Literal

Gate = Literal['compiled','compile_error','invalid_output','compile_timeout']
@dataclass(frozen=True)
class PublicTask:
    id: str
    prompt: str
    repair: bool
    signature: str
    prelude: str

@dataclass(frozen=True)
class Candidate:
    model: str
    response: str
    body: str | None
    tokens: int
    seconds: float

@dataclass(frozen=True)
class GateResult:
    status: Gate
    diagnostic: str = ''
    seconds: float = 0.0
    def __post_init__(self):
        if self.status not in {'compiled','compile_error','invalid_output','compile_timeout'}:
            raise ValueError('Not a compiler-only gate status')

@dataclass(frozen=True)
class Attempt:
    candidate: Candidate
    gate: GateResult

@dataclass(frozen=True)
class Selection:
    attempts: tuple[Attempt,...]
    chosen: Attempt
    @property
    def tokens(self): return sum(x.candidate.tokens for x in self.attempts)
    @property
    def seconds(self): return sum(x.candidate.seconds for x in self.attempts)

def first_choice(task, generate, gate, model='base'):
    candidate=generate(model, task, '')
    return Attempt(candidate,gate(task,candidate.body))

def fallback(task, first, generate, gate, strategy='specialist'):
    if first.gate.status=='compiled': return Selection((first,),first)
    if strategy not in {'specialist','base_feedback'}: raise ValueError('unknown strategy')
    feedback = '' if strategy=='specialist' else (
        '\nYour previous candidate was rejected by the compiler/format check. Fix it, preserving the original requirements.\n'
        'Previous response:\n'+first.candidate.response[:6000]+'\nCompiler diagnostic:\n'+first.gate.diagnostic[:2000])
    candidate=generate('specialist' if strategy=='specialist' else 'base',task,feedback)
    second=Attempt(candidate,gate(task,candidate.body))
    # Only a compiling fallback replaces the original. No functional evaluator access here.
    return Selection((first,second),second if second.gate.status=='compiled' else first)

def solve(task, generate, gate, strategy='specialist'):
    return fallback(task,first_choice(task,generate,gate),generate,gate,strategy)
