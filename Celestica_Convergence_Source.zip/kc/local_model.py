"""Loopback-only llama.cpp client for public task prompts."""
import json
import time
from urllib.parse import urlsplit
from urllib.request import Request, ProxyHandler, build_opener
from cascade import Candidate
from verify import extract

_opener=build_opener(ProxyHandler({}))
class Model:
    def __init__(self,url,adapter=False):
        host=urlsplit(url)
        if host.scheme!='http' or host.hostname not in ('localhost','127.0.0.1') or host.username or host.password or host.path not in ('','/') or host.query or host.fragment:
            raise ValueError('Use a loopback model endpoint.')
        self.url=url.rstrip('/')
        self.adapter=adapter

    def generate(self,task,extra=''):
        data={'messages':[{'role':'user','content':task.prompt+extra}],
              'max_tokens':128,'temperature':0,'seed':1729,
              'chat_template_kwargs':{'enable_thinking':False}}
        if self.adapter: data['lora']=[{'id':0,'scale':1.0}]
        start=time.perf_counter()
        req=Request(self.url+'/v1/chat/completions',json.dumps(data).encode(),{'Content-Type':'application/json'})
        with _opener.open(req,timeout=145) as response:
            x=json.loads(response.read(2**20))
        text=x['choices'][0]['message'].get('content') or ''
        return Candidate('KC step-48 adapter' if self.adapter else 'Qwen3.5-4B Q4_K_M',text,extract(text),
                          x['usage']['completion_tokens'],time.perf_counter()-start)

def revision(first,diagnostic=None):
    prompt='\nRevise your previous answer. Follow the original requirements and return one fenced Rust body.\nPrevious answer:\n'+first.response[:4000]
    return prompt if diagnostic is None else prompt+'\nCompiler or format diagnostic:\n'+diagnostic[:1600]
