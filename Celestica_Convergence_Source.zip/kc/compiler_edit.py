"""Find one machine-applicable rustc edit using only public compilation inputs."""
import json
from pathlib import Path
import subprocess
import tempfile
from confinement import compile_rust
from verify import body_valid

def analyze(task,body):
    if not body or not body_valid(body): return 'invalid_output','One Rust function body is required.',None
    prefix='#![forbid(unsafe_code)]\n'+task.prelude+'\n'+task.signature+' {\n'
    lhs=len(prefix.encode())
    rhs=lhs+len(body.encode())
    raw=(prefix+body+'\n}\nfn main() {}\n').encode()
    with tempfile.TemporaryDirectory() as tmp:
        (Path(tmp)/'candidate.rs').write_bytes(raw)
        try:
            proc=compile_rust(['--target=wasm32-wasip1','--edition=2021','-Awarnings',
                '--emit=metadata','--error-format=json','candidate.rs'],tmp)
        except subprocess.TimeoutExpired:
            return 'compile_timeout','Compilation exceeded the time limit.',None
    if not proc.returncode: return 'compiled','',None
    messages=[]
    proposed=None
    for line in proc.stderr.splitlines():
        try: row=json.loads(line)
        except json.JSONDecodeError: continue
        if row.get('level')!='error': continue
        messages.append(row.get('rendered') or row.get('message',''))
        if proposed is not None: continue
        for msg in [row,*row.get('children',[])]:
            edits=[s for s in msg.get('spans',[]) if s.get('suggested_replacement') is not None]
            if not edits or any(s['file_name']!='candidate.rs' or
                s.get('suggestion_applicability')!='MachineApplicable' or
                not lhs<=s['byte_start']<=s['byte_end']<=rhs for s in edits): continue
            edits.sort(key=lambda s:(s['byte_start'],s['byte_end']))
            if any(a['byte_end']>b['byte_start'] or a['byte_start']==b['byte_start']
                   for a,b in zip(edits,edits[1:])): continue
            patched=raw
            for e in reversed(edits):
                patched=patched[:e['byte_start']]+e['suggested_replacement'].encode()+patched[e['byte_end']:]
            result=patched[lhs:len(patched)-(len(raw)-rhs)].decode()
            if result!=body and body_valid(result):
                proposed=result
                break
    return 'compile_error',('\n'.join(messages) or proc.stderr)[:1600],proposed
