"""Evidence-linked interval constraints for the AxiomForge runtime."""
from collections import Counter, defaultdict
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from enum import StrEnum
import re

import pint

UNITS = pint.UnitRegistry(non_int_type=Decimal)
UNITS.define("USD = [currency]")
NUMBER = re.compile(r"(?<![\w.])[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?(?![\w.])")
IDENTIFIER = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}")


class State(StrEnum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNKNOWN = "UNKNOWN"


def decimal(value):
    """Reject non-finite, boolean, and malformed inputs."""
    try:
        result = Decimal(str(value))
    except InvalidOperation:
        raise ValueError("invalid decimal") from None
    if not result.is_finite():
        raise ValueError("expected a finite number")
    return result


@dataclass(frozen=True)
class Interval:
    low: Decimal
    high: Decimal
    unit: str

    @classmethod
    def read(cls, value):
        if not isinstance(value, dict):
            raise ValueError("quantities require low, high, and unit")
        low, high = decimal(value["low"]), decimal(value["high"])
        unit = value["unit"]
        if low > high or not isinstance(unit, str) or not 1 <= len(unit) <= 80:
            raise ValueError("invalid interval or unit")
        return cls(low, high, unit)

    def in_unit(self, unit):
        a = UNITS.Quantity(self.low, self.unit).to(unit).magnitude
        b = UNITS.Quantity(self.high, self.unit).to(unit).magnitude
        return min(a, b), max(a, b)


@dataclass(frozen=True)
class Evidence:
    document: str
    revision: str
    authority: int
    revision_order: int
    path: str
    quote: str
    location: str
    limit: Interval
    verified: bool

    @classmethod
    def read(cls, item, verified):
        fields = ("document", "revision", "path", "quote", "location")
        if any(not isinstance(item.get(k), str) or not item[k].strip() for k in fields):
            raise ValueError("evidence requires document, revision, path, quote and location")
        quote = item["quote"]
        limit = Interval.read(item["limit"])
        if len(quote) > 500 or any(type(item.get(k)) is not int for k in ("authority", "revision_order")):
            raise ValueError("invalid evidence rank or quote")
        # This verifies transcription support. It cannot decide whether the clause applies.
        normalized = quote.replace(",", "")
        matches = list(NUMBER.finditer(normalized))
        numbers = {decimal(match.group()) for match in matches}
        unit_pattern = re.compile(r"^\s*" + re.escape(limit.unit) + r"(?![\w/])")
        has_unit = any(unit_pattern.match(normalized[match.end():]) for match in matches
                       if decimal(match.group()) in (limit.low, limit.high))
        anchored = {limit.low, limit.high} <= numbers and has_unit
        return cls(item["document"], item["revision"], item["authority"], item["revision_order"],
                   item["path"], quote, item["location"], limit, verified and anchored)


@dataclass(frozen=True)
class Requirement:
    key: str
    hard: bool
    relation: str
    artifact: str
    pointer: str
    unit: str
    depends_on: tuple[str, ...]
    consequence: int
    effort: int
    sources: tuple[Evidence, ...]
    tolerance: Decimal

    def limit(self):
        by_document = defaultdict(list)
        for source in self.sources:
            by_document[source.document].append(source)
        if not by_document:
            return None
        current = [
            s for versions in by_document.values() for s in versions
            if s.revision_order == max(v.revision_order for v in versions)
        ]
        top = max(s.authority for s in current)
        controlling = [s for s in current if s.authority == top]
        if not all(s.verified for s in controlling):
            return None
        try:
            bounds = {s.limit.in_unit(self.unit) for s in controlling}
        except (pint.PintError, ArithmeticError, ValueError):
            return None
        return bounds.pop() if len(bounds) == 1 else None

    def check(self, measurement):
        limit = self.limit()
        if limit is None or measurement is None:
            return State.UNKNOWN
        try:
            low, high = measurement.in_unit(self.unit)
        except (pint.PintError, ArithmeticError, ValueError):
            return State.UNKNOWN
        lower_limit, upper_limit = limit
        if self.relation == "<=":
            if high <= lower_limit - self.tolerance:
                return State.PASS
            if low > upper_limit + self.tolerance:
                return State.FAIL
        if self.relation == ">=":
            if low >= upper_limit + self.tolerance:
                return State.PASS
            if high < lower_limit - self.tolerance:
                return State.FAIL
        return State.UNKNOWN


def verification_order(requirements, states):
    """Prioritize unresolved checks by hard status, consequence, fan-out, and effort."""
    fanout = Counter()
    for requirement in requirements.values():
        upstream = list(requirement.depends_on)
        visited = set()
        while upstream:
            dependency = upstream.pop()
            if dependency not in visited:
                visited.add(dependency)
                upstream.extend(requirements[dependency].depends_on)
        fanout.update(visited)
    urgency = {State.FAIL: 3, State.UNKNOWN: 2, State.PASS: 0}
    return sorted(requirements, key=lambda key: (
        -urgency[states.get(key, State.UNKNOWN)]
        * (1 + int(requirements[key].hard))
        * requirements[key].consequence
        * (1 + fanout[key]) / requirements[key].effort,
        key,
    ))
