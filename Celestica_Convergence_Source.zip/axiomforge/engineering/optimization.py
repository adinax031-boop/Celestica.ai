"""Bounded linear and mixed-integer optimization with independent residual checks."""
from math import isfinite

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from threadpoolctl import threadpool_limits


def solve_linear(variables, rows, direction="min", time_limit=10):
    if not isinstance(variables, list) or not 1 <= len(variables) <= 100:
        raise ValueError("expected 1–100 variables")
    if not isinstance(rows, list) or len(rows) > 500 or direction not in ("min", "max"):
        raise ValueError("invalid rows or direction")
    if type(time_limit) is not int or not 1 <= time_limit <= 20:
        raise ValueError("invalid solver time limit")

    def finite(value):
        if type(value) not in (int, float, str):
            raise ValueError("invalid coefficient")
        result = float(value)
        if not isfinite(result):
            raise ValueError("coefficients must be finite")
        return result

    def bounds(item):
        lo = item.get("lower")
        hi = item.get("upper")
        result = (-np.inf if lo is None else finite(lo), np.inf if hi is None else finite(hi))
        if result[0] > result[1]:
            raise ValueError("lower bound exceeds upper bound")
        return result

    cost = np.array([finite(v.get("coefficient", 0)) for v in variables])
    lower, upper = np.array([bounds(v) for v in variables]).T
    choices = {"continuous": 0, "integer": 1, "binary": 1}
    kinds = [v.get("kind", "continuous") for v in variables]
    integrality = np.array([choices[kind] for kind in kinds])
    for index, kind in enumerate(kinds):
        if kind == "binary":
            lower[index] = max(0, lower[index])
            upper[index] = min(1, upper[index])
            if lower[index] > upper[index]:
                raise ValueError("inconsistent binary bounds")
    matrix = np.empty((len(rows), len(variables)))
    row_bounds = np.empty((len(rows), 2))
    for index, row in enumerate(rows):
        coefficients = row["coefficients"]
        if not isinstance(coefficients, list) or len(coefficients) != len(variables):
            raise ValueError("invalid coefficient row")
        matrix[index] = [finite(value) for value in coefficients]
        row_bounds[index] = bounds(row)
    problem = LinearConstraint(matrix, row_bounds[:, 0], row_bounds[:, 1])
    with threadpool_limits(limits=1):
        result = milp(
            c=cost if direction == "min" else -cost,
            integrality=integrality,
            bounds=Bounds(lower, upper),
            constraints=problem,
            options={"time_limit": time_limit},
        )
    report = {"solver_status": int(result.status), "optimal": result.status == 0}
    if result.x is None:
        return report
    x = np.asarray(result.x)
    activity = matrix @ x
    objective = float(cost @ x)
    integers = x[integrality == 1]
    max_error = max(
        0.0, np.max(lower - x), np.max(x - upper),
        np.max(row_bounds[:, 0] - activity, initial=0),
        np.max(activity - row_bounds[:, 1], initial=0),
        np.max(np.abs(integers - np.round(integers)), initial=0),
    )
    verified = np.all(np.isfinite(x)) and np.all(np.isfinite(activity)) and (
        isfinite(objective) and max_error <= 1e-7
    )
    if verified:
        report.update(values=x.tolist(), objective=objective, max_residual=float(max_error))
    else:
        report["optimal"] = False
        report["residual_check"] = "failed"
    return report
