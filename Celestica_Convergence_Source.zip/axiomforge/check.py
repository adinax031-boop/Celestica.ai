"""Pass/fail cross-check using AxiomForge's original interval constraint implementation."""
from decimal import Decimal
from .engineering.constraints import Requirement, Evidence, Interval

def check_margins(rows):
    units = {'Wh':'watt_hour','W':'watt','kg':'kilogram'}
    expected = ['Eclipse reserve','One-orbit recharge','Bus power in sunlight','Mass ceiling']
    if [x['name'] for x in rows] != expected: raise ValueError("unexpected spacecraft constraints")
    out=[]
    for row in rows:
        unit=units[row['unit']]
        evidence=Evidence.read({'document':'Exhibit power contract','revision':'1','path':'provenance/PROTOCOL.md',
            'quote':f'Minimum allowed margin 0 {unit}', 'location':row['name'],'limit':{'low':0,'high':0,'unit':unit},
            'authority':1,'revision_order':1},True)
        rule=Requirement(row['name'],True,'>=','candidate','margin',unit,(),3,1,(evidence,),Decimal('0'))
        value=float(row['margin'])
        if abs(value)<1e-8: value=0
        status=rule.check(Interval.read({'low':value,'high':value,'unit':unit}))
        out.append({'name':row['name'],'status':status.value})
    return out
