# FRI/VAC Run 10 — validation gate

Date: 2026-11-12. This is a validation/integrity revision of Run 9, not a completed CIFAR-100 experiment.

## Actual results

- 44/44 tests passed (pytest log in `results/run10/pytest_stdout.txt`); this includes all 30 prior tests, with the former permissive lock test corrected to reject the insecure old behavior, plus 14 new tests.
- GEC's projection core was checked against 30 independently solved random feasible primal QPs. This is numerical validation, not full GEC fidelity.
- Official dataset preflight failed (missing train/test/meta); no real training started. Dry-run creates 45 jobs. The execution command exited 2.
- No authenticated P1 held-out accuracy, forgetting, paired uncertainty, or compute-matched comparison exists. Do not treat fixtures as data.
- Runtime: CPU-only PyTorch 2.10.0+cpu. Official Toronto host and Hugging Face DNS failed; separate direct download failed. MIR upstream blob SHA remains 2aa1e63d2ebad1b698ae0116f57aacea465f0ab0; GEC linked repository returned empty (404). Neither full method is author-equivalent.

## Changes

`src/identity.py` centralizes canonical configuration identity, code SHA-256, atomic JSON writes, matrix/metric validation, resource checks. `src/preflight.py` records SHA-256 alongside official MD5. `src/suite.py` checks all existing jobs before executing any new job, requires an exact manifest and content-bound discovery lock based on the 45 validated discovery artifacts. No confirmation lock is issued in this session. `src/run9.py` retains filename for compatibility; it now writes Run 10 reports and requires a matching lock for direct real confirmation. `src/analyze.py` CLI validates data, sources, exact confirmation job set and locked comparator before computing paired statistics. `src/gec_qp.py` fixes multiplier inconsistency after a solver fallback and adds KKT checks. Old results in `results/` are unchanged inherited Run 9 files and are **not** eligible for Run 10 resumption.

Hashes bind expected configuration and artifact contents, but cannot authenticate maliciously fabricated complete records or prove a run occurred; independent execution and controlled storage are still required. The statistical helper used by unit tests is not an authenticated entry point. This pipeline is an initial fixed-configuration CPU gate, not a full P1 study or GPU harness. The three methods are not compute matched. Confirmation comparison requires a real discovery lock; scientific promotion remains disabled, even if exploratory training completes.

## Resume commands (local authentic CIFAR-100, CPU runner)

Extract the official `cifar-100-python.tar.gz` into `data/`, such that `data/cifar-100-python/{train,test,meta}` exist. Official archive MD5: `eb9058c3a382ffc7106e4002c42a8d85`. The preflight verifies the individual official MD5 hashes, the data sizes, and records SHA-256.

```bash
python -m pytest -q src
python src/preflight.py --dataset-root data --out results/p1_provenance.json
python src/suite.py --dataset-root data --out results/p1_discovery --max-jobs 1
```

The last command is exploratory baseline training only, not a matched scientific comparison. Do not use inherited result directories. Before spending compute on the 45-job discovery queue, resolve reference-method fidelity and predeclare a true compute budget control. The runner is CPU-only; GPU execution requires an independently tested device port. Do not start confirmation until method fidelity, resource matching, and discovery completeness are reviewed.

## Decision

Retain integrity fixes and numerical validation. Reject any scientific promotion. P1 baseline gate remains blocked on dataset provenance, full method fidelity, and compute matching. ResNet18 remains deferred. Preserve Run 9 original ZIP separately.
