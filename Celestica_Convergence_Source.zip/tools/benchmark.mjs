import fs from 'node:fs';
import {finish,POLICIES} from '../lab/memory.mjs';
import {ablation} from '../lab/axiom.mjs';
const seedList=[917,918,919,920,921];
const evidence={study:'Convergence exhibit-scale experiments',seeds:seedList,steps:44,axiom:ablation(),memory:{}};
const mean=a=>a.reduce((x,y)=>x+y,0)/a.length;
for(const mode of ['digits','engineering']){
 const arms=Object.fromEntries(POLICIES.map(policy=>[policy,seedList.map(seed=>finish({mode,policy,seed}))]));
 const stats={};
 for(const [arm,rows] of Object.entries(arms)){
  const fields=['retention','newAccuracy','forgetting','averageAcquisition','AP','prevalence','wallMs'];
  stats[arm]=Object.fromEntries(fields.map(f=>[f,mean(rows.map(r=>r[f]??0))]));
  stats[arm].retentionBySeed=rows.map(r=>r.retention);
  stats[arm].pairedVsReplay=rows.map((r,i)=>r.retention-arms.replay[i].retention);
  stats[arm].counts=Object.fromEntries(Object.keys(rows[0].counts).map(k=>[k,mean(rows.map(r=>r.counts[k]))]));
 }
 evidence.memory[mode]={stats,arms};
}
fs.writeFileSync(new URL('../evidence/benchmark.json',import.meta.url),JSON.stringify(evidence,null,2)+'\n');
for(const [name,x] of Object.entries(evidence.memory))console.log(name,JSON.stringify(x.stats));
console.log('axiom',evidence.axiom);
