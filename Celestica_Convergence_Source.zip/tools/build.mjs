import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=new URL('../',import.meta.url);
const cli=process.env.CELESTICA_ESBUILD||'esbuild';
const result=spawnSync(cli,[fileURLToPath(new URL('lab/app.mjs',root)),'--bundle','--format=iife','--target=es2022','--charset=utf8'],
 {encoding:'utf8',maxBuffer:12*1024*1024});
if(result.status!==0)throw Error(result.stderr||String(result.error));
const read=name=>fs.readFileSync(new URL(name,root),'utf8');
const html=read('lab/template.html').replace('/*STYLE*/',()=>read('lab/style.css'))
  .replace('/*BUNDLE*/',()=>result.stdout.replaceAll('</script','<\\/script'));
fs.writeFileSync(new URL('index.html',root),html);
