"""Local-only exhibit server. Curated challenge specs and isolated Rust evaluation."""
import argparse
from dataclasses import asdict
from functools import partial
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
import json
from pathlib import Path
import sys
from threading import BoundedSemaphore
from urllib.parse import urlsplit
APP=Path(__file__).resolve().parent
sys.path.insert(0,str(APP.parent/'02_Research/source'))
from cascade import PublicTask,Candidate
from compiler_edit import analyze
from demo_tasks import demos
from local_model import Model,revision
from verify import smoke,verify

slot=BoundedSemaphore(1)
def run(t,base,adapter,method):
    p=PublicTask(t.id,t.prompt(),bool(t.broken),t.sig,t.prelude)
    c=base.generate(p)
    gate,diag,edit=analyze(p,c.body)
    attempts=[(c,gate,diag)]
    chosen=attempts[0]
    if method=='adapter':
        a=adapter.generate(p)
        s,d,_=analyze(p,a.body)
        chosen=(a,s,d)
        attempts.append(chosen)
    elif method in {'verify','kc_retry'} and gate!='compiled':
        if method=='verify' and edit:
            s,d,_=analyze(p,edit)
            a=(Candidate('rustc suggestion','',edit,0,0),s,d)
            attempts.append(a)
            if s=='compiled': chosen=a
        if chosen[1]!='compiled':
            model=base if method=='verify' else adapter
            a=model.generate(p,revision(c,diag))
            s,d,_=analyze(p,a.body)
            attempts.append((a,s,d))
            if s=='compiled': chosen=attempts[-1]
    def describe(value):
        c,s,d=value
        result,detail=verify(t,c.body or '')
        return {'model':c.model,'body':c.body or c.response,'compiler':s,
                'diagnostic':d,'functional':result,'test_diagnostic':detail,
                'seconds':round(c.seconds,2),'tokens':c.tokens}
    first=describe(attempts[0])
    return {'id':t.id,'spec':t.spec,'signature':t.sig,'initial':first,
            'selected':first if chosen==attempts[0] else describe(chosen),
            'calls':sum(c.model!='rustc suggestion' for c,_,_ in attempts),
            'tokens':sum(c.tokens for c,_,_ in attempts),
            'seconds':round(sum(c.seconds for c,_,_ in attempts),2),
            'attempts':[{'model':c.model,'compiler':s,'diagnostic':d} for c,s,d in attempts]}

class App(BaseHTTPRequestHandler):
    def __init__(self,*args,base,adapter,cases,**kwargs):
        self.base,self.adapter,self.cases=base,adapter,cases
        super().__init__(*args,**kwargs)
    def result(self,status,data,kind='application/json'):
        raw=data if isinstance(data,bytes) else json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type',kind+'; charset=utf-8')
        self.send_header('Content-Length',str(len(raw)))
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Cache-Control','no-store')
        self.end_headers()
        self.wfile.write(raw)
    def host_ok(self):
        return self.headers.get('Host','').partition(':')[0] in {'127.0.0.1','localhost'}
    def do_GET(self):
        if not self.host_ok(): return self.send_error(403)
        if self.path=='/': return self.result(200,(APP/'index.html').read_bytes(),'text/html')
        if self.path=='/api/status': return self.result(200,{'specialist':bool(self.adapter)})
        return self.send_error(404)
    def do_POST(self):
        origin=urlsplit(self.headers.get('Origin',''))
        if not self.host_ok() or (origin.netloc and origin.netloc!=self.headers.get('Host')): return self.send_error(403)
        try: _,api,op,method,key=self.path.split('/')
        except ValueError: return self.send_error(404)
        if (api,op)!=('api','run') or method not in {'base','verify','adapter','kc_retry'} or key not in self.cases:
            return self.send_error(404)
        if method in {'adapter','kc_retry'} and not self.adapter: return self.result(400,{'error':'Adapter is unavailable.'})
        if not slot.acquire(False): return self.result(429,{'error':'Another experiment is running.'})
        try:
            evidence=run(self.cases[key],self.base,self.adapter,method)
            self.result(200,evidence)
        except (BrokenPipeError,ConnectionResetError):
            pass
        except Exception as ex:
            self.log_error('Experiment failed (%s)',type(ex).__name__)
            self.result(503,{'error':'Live inference is unavailable. Continue with an offline mode.'})
        finally: slot.release()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--port',type=int,default=8040)
    ap.add_argument('--model-url',default='http://127.0.0.1:9099')
    ap.add_argument('--with-adapter',action='store_true')
    args=ap.parse_args()
    smoke()
    cases={t.id:t for t in demos()}
    for t in cases.values():
        if verify(t,t.body,trusted=True)[0]!='pass': raise RuntimeError('Reference failed: '+t.id)
        if t.broken and verify(t,t.broken,trusted=True)[0] not in {'compile_error','test_failure'}:
            raise RuntimeError('Negative control failed: '+t.id)
    factory=partial(App,base=Model(args.model_url),adapter=Model(args.model_url,True) if args.with_adapter else None,cases=cases)
    with ThreadingHTTPServer(('127.0.0.1',args.port),factory) as server:
        print(f'http://127.0.0.1:{args.port}',flush=True)
        server.serve_forever()
if __name__=='__main__': main()
