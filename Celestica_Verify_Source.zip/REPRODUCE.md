# Reproducing Celestica Verify

## Offline

Open `04_Exhibition_App/index.html`. Recorded experiments and the interactive simulation work without downloads. Live inference has a distinct label.

## Linux live mode

Use Python 3.11+, bubblewrap with unprivileged user namespaces, prlimit, libseccomp and Rust 1.85.1 with the wasm32-wasip1 target. Place the Rust distribution under a single installation prefix. Pin the Python execution dependency with `pip install wasmtime==30.0.0`.

Download the [pinned Qwen GGUF](https://huggingface.co/ggml-org/Qwen3.5-4B-GGUF/resolve/8d43d974efc48399cb58957ad49c8b26bf5a109c/Qwen3.5-4B-Q4_K_M.gguf). Its SHA-256 is `217002fa8008ef4fc6d548353a3aebef055a96e6ff8e0e2c0953ef8254a89c14`. The GGUF uses Q4_K_M and the original training archive used NF4. Treat the quantization conditions separately.

```sh
llama-server -m Qwen3.5-4B-Q4_K_M.gguf --host 127.0.0.1 --port 9099 -t 4 -np 1 -c 4096 -ngl 0 --reasoning off
```

In another terminal:

```sh
export CELESTICA_RUST_ROOT=/absolute/path/to/rust-prefix
python 04_Exhibition_App/serve.py
```

Open the reported loopback URL. For a compatible authentic local LoRA, start llama.cpp with `--lora <file> --lora-init-without-apply` and add `--with-adapter` to the exhibit command. The public archive excludes model weights. The app does not accept arbitrary code submissions.

## Control study

The fresh set is deterministically recreated by the pinned-source qualification script. Install `pyarrow`. Before testing, recover the earlier Mission 02 frozen development manifest from the original project research archive. Its training and older test cases are needed to preserve exclusions. Use the immutable dataset:

```text
https://huggingface.co/datasets/bigcode/humanevalpack/resolve/9a41762f73a8cb23bb5811b73d5aab164efcf378/rust/test-00000-of-00001.parquet
```

```sh
export PYTHONPATH="$PWD/02_Research/source"
export CELESTICA_RUST_ROOT=/absolute/path/to/rust-prefix
mkdir -p run
python 02_Research/source/fresh.py /path/to/mission02/evidence/frozen_manifest.json run rust.parquet
python 02_Research/source/study.py controls run run rust.parquet
```

Keep generated benchmark tests away from prompts and routing. SHA-256 of the frozen manifest is recorded in `03_Benchmarks/fresh_manifest.sha256`. Use the Mission 02 evidence directory to recheck archived model outputs with the `study.py archive` command. See `03_Benchmarks/Frozen_Protocol.md` for controls and promotion thresholds.
