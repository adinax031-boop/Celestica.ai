"""Pinned public benchmarks and a full Rust-language census of the Flash release."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re

from tasks import Task

FLASH = "sollamon/ox-alpha-glm-5.3-flash-distillation-coding-17k-raw"
HUMAN = "bigcode/humanevalpack"
MULTI = "nuprl/MultiPL-E"
STOP = set("a an the in of to for with and that it its is as by from on or be should write implement create rust function program given take takes return returns fn mut let".split())

def terms(text):
    return set(re.findall(r"[a-z0-9_]+",text.lower())) - STOP

def similarity(a,b):
    return len(a & b) / max(1,len(a | b))

def pin_fetch(repo, path, revision):
    from huggingface_hub import hf_hub_download
    return Path(hf_hub_download(repo, path, revision=revision, repo_type="dataset"))

def audit_flash(api, out, prompts):
    revision=api.dataset_info(FLASH).sha
    files=api.list_repo_files(FLASH,revision=revision,repo_type="dataset")
    source=pin_fetch(FLASH,next(name for name in files if name.endswith(".jsonl")),revision)
    counts=Counter()
    prompts=[terms(x) for x in prompts]
    seen=set()
    near=[]
    families=Counter()
    for line in source.open(encoding="utf8"):
        row=json.loads(line)
        counts["total"]+=1
        if str(row.get("language","")).strip().lower() != "rust":
            continue
        counts["rust"]+=1
        prompt=str(row.get("instruction","")).strip()
        code=str(row.get("code","")).strip()
        if not prompt or not code:
            counts["missing_fields"]+=1
            continue
        normalized=(" ".join(prompt.lower().split())," ".join(code.split()))
        if normalized in seen:
            counts["exact_duplicates"]+=1
            continue
        seen.add(normalized)
        token_set=terms(prompt)
        if any(similarity(token_set,b)>=.65 for b in prompts):
            counts["benchmark_overlap_flags"]+=1
            continue
        if any(similarity(token_set,b)>=.72 for b in near):
            counts["near_duplicate_flags"]+=1
            continue
        near.append(token_set)
        key=next((group for group, keys in (
            ("ownership", {"borrow","ownership","lifetime","lifetimes","move"}),
            ("parsing", {"parse","parsing","parser","config"}),
            ("generics", {"generic","generics","trait","traits"}),
            ("concurrency", {"thread","threads","concurrent","mutex","channel"}),
            ("algorithms", {"sort","frequency","search","count","sorted"}))
            if token_set & keys),"other")
        families[key]+=1
        counts["distinct_unqualified"]+=1
        counts["explicit_test_attribute"]+=int(bool(re.search(r"#\s*\[\s*test\s*\]",code)))
    report={"repo":FLASH,"revision":revision,"sha256":sha256(source.read_bytes()).hexdigest(),
            "counts":dict(counts),"heuristic_families":dict(families),"training_eligible_rows":0,
            "reason":"Release card states training intent and MIT. Origin is a hosted alias and upstream generation terms are undocumented. Independent functional tests are missing for the sampled candidates."}
    (out/"teacher_audit.json").write_text(json.dumps(report,indent=2))
    print("TEACHER AUDIT",json.dumps(report),flush=True)

def public_suites(api):
    datasets={}
    for repo,config in [(HUMAN,"rust"),(MULTI,"humaneval-rs")]:
        revision=api.dataset_info(repo).sha
        files=api.list_repo_files(repo,revision=revision,repo_type="dataset")
        candidates=[f for f in files if re.search(rf"(^|/){config}/",f) and f.endswith((".parquet",".jsonl",".json"))]
        if not candidates:
            raise RuntimeError(f"Could not locate files for {repo} {config}: {files[:24]}")
        path=pin_fetch(repo,candidates[0],revision)
        if path.suffix==".parquet":
            import pyarrow.parquet as pq
            records=pq.read_table(path).to_pylist()
        else:
            raw=path.read_text()
            records=json.loads(raw) if raw.lstrip().startswith("[") else [json.loads(l) for l in raw.splitlines() if l]
        datasets[repo]=(records,revision,sha256(path.read_bytes()).hexdigest())
    return datasets

def human_task(row, repair=False):
    mode="repair" if repair else "generation"
    signature=row["signature"].strip()
    if not signature.startswith("fn "):
        signature="fn "+signature
    canonical=row["canonical_solution"].strip()
    if not canonical.endswith("}"):
        return None
    tests = row["test"].strip()
    test_names=re.findall(r"#\[test\]\s*(?:pub\s+)?fn\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(\s*\)",tests)
    if not test_names or not re.match(r"#\[cfg\(test\)\]\s*mod tests\s*\{",tests):
        return None
    visible=re.sub(r"#\[cfg\(test\)\]","",tests,count=1)
    visible=re.sub(r"#\[test\]\s*(?:pub\s+)?fn\s+(\w+)",r"pub fn \1",visible)
    setup=(row.get("test_setup") or "").strip()
    prelude='use std::{slice::Iter,cmp::{max,min,self},mem::replace,collections::{HashSet,HashMap},ops::Index,ascii::AsciiExt,any::{Any,TypeId}};\n'+(row.get("import") or "")
    broken=row["buggy_solution"].strip().removesuffix("}").strip() if repair else ""
    task=Task(row["task_id"]+":"+mode,row.get("bug_type") if repair else "general","unrated",
              row["docstring"].strip(),signature,canonical.removesuffix("}").strip(),
              " ".join(f"tests::{name}();" for name in test_names),broken,
              prelude,"HumanEvalPack Rust "+mode,HUMAN,harness=setup+"\n"+visible)
    return task

def multipl_task(row):
    prompt=row["prompt"].strip()
    match=re.search(r'(?:^|\n)(fn [^{}]+)\{\s*$',prompt)
    tests=re.match(r'^\s*}\s*fn main\(\)\s*\{(.*)\}\s*$',row["tests"],re.S)
    if not match or not tests:
        return None
    prelude="\n".join(line for line in prompt[:match.start()].splitlines() if line.strip().startswith("use "))
    if re.search(r"\b(?:regex|rand|md5|itertools|num)::", prelude + tests[1]):
        return None
    spec="\n".join(line.strip().removeprefix("///").strip() for line in prompt[:match.start()].splitlines() if line.strip().startswith("///"))
    if not spec:
        return None
    return Task(row["name"],"general","unrated",spec,match[1].strip(),"",tests[1].strip(),
                prelude=prelude,suite="MultiPL-E Rust HumanEval",source=MULTI,license="MIT")
