"""Freeze 60 new HumanEvalPack Rust IDs, one mode per underlying problem.
References and negative controls must pass real WASI verification before inference.
The public benchmark may be present in pretraining; fresh means unseen in this project.
"""
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import json, re, sys
from sources import HUMAN, pin_fetch, human_task, similarity, terms
from tasks import Task
from verify import verify_many, smoke
SEED='celestica-m02-20261119-v1'

def underlying(id):
    m=re.match(r'Rust/(\d+):|HumanEval_(\d+)_',id)
    return int(m[1] or m[2]) if m else None

def freeze(old, out, source_path=None):
    import pyarrow.parquet as pq
    info=old['public'][HUMAN]; revision=info['revision']
    p = Path(source_path) if source_path else pin_fetch(HUMAN, 'rust/test-00000-of-00001.parquet', revision)
    if sha256(p.read_bytes()).hexdigest()!=info['sha256']: raise RuntimeError('dataset digest changed')
    if p.suffix=='.parquet': records=pq.read_table(p).to_pylist()
    else:
        raw=p.read_text(); records=json.loads(raw) if raw.lstrip().startswith('[') else [json.loads(l) for l in raw.splitlines() if l.strip()]
    used={underlying(t['id']) for t in old['rows']['evaluation']}
    old_specs=[terms(t['spec']) for v in old['rows'].values() for t in v]
    eligible=[r for r in records if underlying(r['task_id']+':generation') not in used and not any(similarity(terms(r['docstring']),s)>=.72 for s in old_specs)]
    ordered=sorted(eligible,key=lambda r:sha256((SEED+r['task_id']).encode()).hexdigest())
    accepted=[]; audit=[]; seen=set(); counts={False:0,True:0}
    # Modes are assigned by fixed order, not model performance. Refill only on reference/control invalidity.
    for row in ordered:
        idx=underlying(row['task_id']+':generation')
        if idx is None or idx in seen: continue
        repair=counts[True]<counts[False] or counts[False]>=30
        t=human_task(row,repair=repair)
        # Verify reference and original published buggy body even for generation tasks.
        neg=human_task(row,repair=True)
        if not t or not neg or not neg.broken: continue
        (s,e),(bs,be)=verify_many([(t,t.body),(neg,neg.broken)],trusted=True)
        audit.append({'id':t.id,'reference':s,'negative_control':bs})
        if s!='pass' or bs not in {'compile_error','test_failure'}: continue
        accepted.append(t); seen.add(idx); counts[repair]+=1
        if len(accepted)==60: break
    out.mkdir(parents=True,exist_ok=True)
    (out/'qualification.json').write_text(json.dumps(audit,indent=2)+'\n')
    if len(accepted)!=60 or counts!={False:30,True:30}: raise RuntimeError(f'Fresh qualification insufficient: {counts}')
    manifest={'source':HUMAN,'revision':revision,'source_sha256':info['sha256'],'seed':SEED,'mode_counts':{'generation':30,'repair':30},'rows':[asdict(t) for t in accepted],'qualification':'reference passes and original broken body fails independent assertions','warning':'public benchmark; unknown base pretraining exposure; no Mission 01 IDs or near-duplicate specs'}
    path=out/'fresh_manifest.json';path.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n'); (out/'fresh_manifest.sha256').write_text(sha256(path.read_bytes()).hexdigest()+'\n')
    return accepted

if __name__=='__main__':
    smoke(); freeze(json.loads(Path(sys.argv[1]).read_text()),Path(sys.argv[2]),sys.argv[3] if len(sys.argv)>3 else None)
