"""Compile only, never include functional tests or hidden harness in the selection gate."""
from pathlib import Path
import shutil, subprocess, tempfile, time
from verify import body_valid
from confinement import compile_rust
from cascade import GateResult

def compile_only(task, body):
    start=time.perf_counter()
    if not body or not body_valid(body): return GateResult('invalid_output','Expected a safe, single Rust body in one fenced block.')
    rustc=shutil.which('rustc') or str(Path.home()/'.cargo/bin/rustc')
    src='#![forbid(unsafe_code)]\n'+task.prelude+'\n'+task.signature+' {\n'+body+'\n}\nfn main() {}\n'
    with tempfile.TemporaryDirectory(prefix='kc-gate-') as tmp:
        (Path(tmp)/'candidate.rs').write_text(src)
        try:
            result=compile_rust(['--target=wasm32-wasip1','--edition=2021','-Awarnings','--crate-name=kc_gate','candidate.rs','-o','candidate.wasm'],cwd=tmp)
        except subprocess.TimeoutExpired: return GateResult('compile_timeout','Compilation exceeded time cap.',time.perf_counter()-start)
        return GateResult('compiled' if result.returncode==0 else 'compile_error',result.stderr[-2000:] if result.returncode else '',time.perf_counter()-start)
