"""Recompile the logged archive and run the frozen project-fresh compiler-only arm."""
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
from cascade import PublicTask
from compiler_edit import analyze
from fresh import underlying
from replay import load,exact_p
from sources import human_task
from tasks import Task
from verify import verify,smoke

def read(p): return json.loads(p.read_text())
def dump(path,obj): path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

def run(kind,source,out,dataset=None):
    smoke()
    start=time.perf_counter()
    if kind=='archive':
        tasks=[Task(**v) for v in read(source/'frozen_manifest.json')['rows']['evaluation']]
        earlier=load(source)
        names=('base','adapter','route','compiler_edit','edit_then_route')
    else:
        import pyarrow.parquet as pq
        frozen=read(source/'fresh_manifest.json')
        assert sha256(dataset.read_bytes()).hexdigest()==frozen['source_sha256']
        dataset_rows={v['task_id']:v for v in pq.read_table(dataset).to_pylist()}
        tasks=[human_task(dataset_rows[row['id'].rsplit(':',1)[0]],True) for row in frozen['rows']]
        assert len(tasks)==len({underlying(t.id) for t in tasks})==60
        names=('base','compiler_edit')
    def select(t):
        began=time.perf_counter()
        public=PublicTask(t.id,'',bool(t.broken),t.sig,t.prelude)
        base=earlier[0][t.id]['body'] if kind=='archive' else t.broken
        s,d,suggestion=analyze(public,base)
        first={'body':base,'compiler':s,'diagnostic':d,'source':'base'}
        fixed=first
        if suggestion:
            status,diag,_=analyze(public,suggestion)
            if status=='compiled':
                fixed={'body':suggestion,'compiler':status,'diagnostic':diag,'source':'rustc suggestion'}
        choices={'base':first,'compiler_edit':fixed}
        if kind=='archive':
            body=earlier[1][t.id]['body']
            status,diag,_=analyze(public,body)
            adapter={'body':body,'compiler':status,'diagnostic':diag,'source':'adapter'}
            route=adapter if s!='compiled' and status=='compiled' else first
            choices.update(adapter=adapter,route=route,edit_then_route=(fixed if fixed is not first else route))
        return dict(id=t.id,repair=bool(t.broken),choices=choices,proposed=bool(suggestion),
                    select_seconds=time.perf_counter()-began)
    with ThreadPoolExecutor(max_workers=3) as pool:
        selected=list(pool.map(select,tasks))
    selected_file=out/f'{kind}_selections.json'
    dump(selected_file,selected)
    def score(item):
        t,row=item
        cache={}
        for arm in row['choices'].values():
            body=arm['body'] or ''
            if body not in cache: cache[body]=verify(t,body,trusted=(kind!='archive'))[0]
            arm['status']=cache[body]
        return row
    with ThreadPoolExecutor(max_workers=3) as pool:
        rows=list(pool.map(score,zip(tasks,selected)))
    results={}
    for name in names:
        all_choices=[r['choices'][name] for r in rows]
        b=[r['choices']['base']['status']=='pass' for r in rows]
        a=[r['status']=='pass' for r in all_choices]
        gains=sum(y and not x for x,y in zip(b,a))
        losses=sum(x and not y for x,y in zip(b,a))
        results[name]={'passed':sum(a),'compiled':sum(r['compiler']=='compiled' for r in all_choices),
            'invalid':sum(r['compiler']=='invalid_output' for r in all_choices),
            'repair':sum(flag and row['repair'] for flag,row in zip(a,rows)),
            'generation':sum(flag and not row['repair'] for flag,row in zip(a,rows)),
            'gains':gains,'losses':losses,'mcnemar_exact_descriptive':exact_p(gains,losses),
            'edits_accepted':sum(r['source']=='rustc suggestion' for r in all_choices)}
    if kind!='archive' and results['base']['passed']: raise RuntimeError('invalid negative control')
    report={'n':len(tasks),'arms':results,'compiler_only_proposals':sum(r['proposed'] for r in rows),
          'compile_errors_initial':sum(r['choices']['base']['compiler']=='compile_error' for r in rows),
          'selection_seconds_sum':sum(r['select_seconds'] for r in rows),
          'wall_seconds':time.perf_counter()-start,'new_model_calls':0,
          'selections_sha256':sha256(selected_file.read_bytes()).hexdigest(),'rows':rows}
    dump(out/f'{kind}_results.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2),flush=True)

if __name__=='__main__':
    run(sys.argv[1],Path(sys.argv[2]),Path(sys.argv[3]),Path(sys.argv[4]) if len(sys.argv)>4 else None)
