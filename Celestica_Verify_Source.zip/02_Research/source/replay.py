"""Archived replay; compiler-only status proxy, not fresh Rust execution."""
from pathlib import Path
from dataclasses import asdict
import collections, json, math, statistics, sys
from cascade import Candidate, GateResult, PublicTask, Attempt, fallback

COMPILED={'pass','test_failure'}
ALLOWED=COMPILED|{'invalid_output','compile_error','compile_timeout'}
def gate_proxy(status):
    if status not in ALLOWED: raise ValueError('unexpected archive status '+status)
    return GateResult('compiled' if status in COMPILED else status)

def load(root):
    data=[json.loads((root/f'{n}.json').read_text())['rows'] for n in ['baseline','specialist']]
    maps=[{r['id']:r for r in rows} for rows in data]
    if len(maps[0])!=len(data[0]) or len(maps[1])!=len(data[1]) or set(maps[0])!=set(maps[1]): raise ValueError('mismatched IDs')
    for k in maps[0]:
        if maps[0][k]['repair']!=maps[1][k]['repair']: raise ValueError('mode mismatch')
    return maps

def exact_p(g,l):
    n=g+l
    return min(1.,2*sum(math.comb(n,k) for k in range(min(g,l)+1))/2**n) if n else 1.

def study(root):
    a,b=load(root); models={'base':a,'specialist':b}; reports={}
    for policy in ['base','specialist','mode_router','base_first','repair_first','adapter_first']:
        rows=[]
        for tid,x in a.items():
            t=PublicTask(tid,'',x['repair'],'','')
            def get(model):
                r=models[model][tid]
                return Candidate(model,r['response'],r['body'],r['tokens'],r['seconds'])
            def make(model): return Attempt(get(model),gate_proxy(models[model][tid]['status']))
            first='specialist' if policy in ['specialist','adapter_first'] or policy in ['mode_router','repair_first'] and t.repair else 'base'
            attempt=make(first)
            used=[attempt]; chosen=attempt
            if policy in ['base_first','repair_first','adapter_first'] and attempt.gate.status!='compiled':
                other='base' if first=='specialist' else 'specialist'
                if first=='base':
                    sel=fallback(t,attempt,lambda m,t,f:get(m),lambda t,body:gate_proxy(models[other][tid]['status']))
                    used=list(sel.attempts);chosen=sel.chosen
                else:
                    used.append(make(other));chosen=used[-1] if used[-1].gate.status=='compiled' else attempt
            y=models[chosen.candidate.model][tid]
            rows.append({'id':tid,'repair':t.repair,'chosen':chosen.candidate.model,'status':y['status'],'first_gate':attempt.gate.status,'calls':len(used),'tokens':sum(u.candidate.tokens for u in used),'seconds':sum(u.candidate.seconds for u in used),'base_status':x['status']})
        g=sum(r['status']=='pass' and r['base_status']!='pass' for r in rows);l=sum(r['status']!='pass' and r['base_status']=='pass' for r in rows)
        reports[policy]={'n':len(rows),'passed':sum(r['status']=='pass' for r in rows),'compiled':sum(r['status'] in COMPILED for r in rows),'invalid':sum(r['status']=='invalid_output' for r in rows),'repair_pass':sum(r['status']=='pass' and r['repair'] for r in rows),'generation_pass':sum(r['status']=='pass' and not r['repair'] for r in rows),'gains':g,'losses':l,'exact_p_descriptive':exact_p(g,l),'calls':sum(r['calls'] for r in rows),'tokens':sum(r['tokens'] for r in rows),'generation_seconds':sum(r['seconds'] for r in rows),'median_generation_seconds':statistics.median(r['seconds'] for r in rows),'rows':rows}
    return {'evidence':'retrospective archived replay, no fresh inference or compilation; gate proxy uses archived compiled/not compiled only','policies':reports,'oracle_any':sum(a[k]['status']=='pass' or b[k]['status']=='pass' for k in a),'archive_verdicts':{m:dict(collections.Counter(r['status'] for r in z.values())) for m,z in models.items()},'token_cap_hits':{m:sum(r['tokens']==128 for r in z.values()) for m,z in models.items()}}
if __name__=='__main__':
    report=study(Path(sys.argv[1]));Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n')
    for name,x in report['policies'].items(): print(name,{k:v for k,v in x.items() if k!='rows'})
