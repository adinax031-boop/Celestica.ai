# Source decisions

| Source | Card license | Training decision |
|---|---|---|
| [Ox Alpha GLM-5.3-Flash](https://huggingface.co/datasets/sollamon/ox-alpha-glm-5.3-flash-distillation-coding-17k-raw) | MIT | Audit only. The model identity is asserted by the publisher using an OpenCode alias. The exact originating terms and independent tests are missing. |
| [Open Athena recursive task synthesis](https://huggingface.co/datasets/open-athena/recursive-task-synthesis-glm-5.3-rollouts) | CC BY 4.0 | Strongest GLM candidate for a later repair study. The card pins the upstream CC BY 4.0 task release and reports 12,124 successful logical attempts across languages. Require Rust package detection, per-repository license review, source-family grouping, and independent replay. The 260.5 GiB payload is separate from compact indexes. |
| [Open Athena RLVR1](https://huggingface.co/datasets/open-athena/GLM-5.3-RLVR1-Training-Rollouts-2026.09.25) | Apache-2.0 | Hold. The 33,109 normalized chats include 11,397 terminal tool calls that the collector did not execute. The raw/chat/rendered representations share records. |
| [Jackrong GLM-5.1 cleaned](https://huggingface.co/datasets/Jackrong/GLM-5.1-Reasoning-1M-Cleaned) | Apache-2.0 | Hold. Its card names the upstream derivative and reports 746,321 kept rows across four topics. It supplies no verified Rust subset or independent tests. |
| [Strandset-Rust-v1](https://huggingface.co/datasets/Fortytwo-Network/Strandset-Rust-v1) | Apache-2.0 | Upstream crate licenses must be resolved per row. Card reports 191,008 training rows, mixed task types, and aggregate compilation. The card’s consensus and compilation results do not replace independent functional testing. |
| [RLVR code data Rust](https://huggingface.co/datasets/saurabh5/rlvr-code-data-Rust) | None declared in fetched card | Hold. 133,296 published translated rows include test fields. Validate original source rights, requirements, translated tests, and overlap before training. |
| [CodeAlchemy Rust](https://huggingface.co/datasets/adityabhushannagar/code-alchemy-rust) | Other | Derivative with separate evaluation configurations. Hold while resolving original terms, execution evidence, and row eligibility. |
| [RustEvo²](https://huggingface.co/datasets/SYSUSELab/RustEvo2) | Apache-2.0 | Candidate for an API-evolution holdout. Reserve from training. |

The pilot uses new project-authored, AI-assisted specifications, code, and assertions. These have no GLM lineage. The model training is supervised specialization on verified references. A GLM distillation claim requires actual trace provenance and a measured qualifying training run.

## Model candidates

| Candidate | Architecture | License | Decision |
|---|---|---|---|
| [Qwen3.5-4B](https://huggingface.co/Qwen/Qwen3.5-4B) | Hybrid linear and full attention, multimodal, about 4.66B total Hub parameters | Apache-2.0 | First T4 run. NF4 weights, FP16 computation, text input, rank-16 LoRA. |
| [Qwen3.5-9B](https://huggingface.co/Qwen/Qwen3.5-9B) | Same family, about 9.65B total Hub parameters | Apache-2.0 | Reserve until a controlled 4B result and measured memory headroom. Parallel T4 allocation does not pool VRAM automatically. |
| [Qwen3-4B](https://huggingface.co/Qwen/Qwen3-4B) | Text-only transformer, about 4.02B parameters | Apache-2.0 | Fallback with a simpler stack and mature quantization. Rust-specific speed and capability still need matched evaluation. |
| [Qwen3.5-0.8B](https://huggingface.co/Qwen/Qwen3.5-0.8B) | Smaller hybrid multimodal model | Apache-2.0 | Candidate for lower-memory exhibition deployment if evaluated independently. |
| [LiquidAI d1-3B](https://huggingface.co/LiquidAI/d1-3B) | Compact multimodal model aimed at decision and classification use | See model release terms | Recent edge option. No retrieved Rust repair result justifies replacing the 4B candidate. |

## Related work

- Dettmers et al. (2023), [QLoRA](https://arxiv.org/abs/2305.14314), describes NF4 and low-rank tuning of frozen quantized base weights.
- Muennighoff et al. (2023), [OctoPack and HumanEvalPack](https://arxiv.org/abs/2308.07124), provides code synthesis and repair evaluation in Rust.
- Cassano et al. (2022), [MultiPL-E](https://arxiv.org/abs/2208.08227), establishes multilingual translation of unit-test benchmarks.
- Le et al. (2022), [CodeRL](https://arxiv.org/abs/2207.01780), uses functional execution outcomes to improve code generation and precedes this project’s broader premise.
- [Wasmtime fuel](https://docs.wasmtime.dev/examples-interrupting-wasm.html) supports bounded execution. Mission 01 uses a short, single-file WASI evaluator. The recovered Docker verifier remains the route for realistic repositories and native concurrency.
