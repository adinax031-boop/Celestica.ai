# Celestica KC · Mission 02 — Compiler-gated specialist recovery

**Research question:** Can a lightweight, fine-tuned Rust specialist recover useful answers from an otherwise weaker adapter without sacrificing the original model's compiling outputs?

**Decision:** Retain Qwen3.5-4B as the incumbent. Retain the step-48 adapter as a challenger for bounded compiler-gated fallback, not as a standalone replacement. The 30 old tasks are development evidence. No generalization or SOTA claim.

## 1. Evidence and diagnostic audit

Mission 01 used Qwen/Qwen3.5-4B at revision `851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a`, 27 verified authored training operations, 3 validation operations, 48 rank-16 QLoRA updates and 2,085 supervised tokens. The actual recorded trainable parameter count was 21,233,664 / 4,560,499,200 (0.4656%). Mission 02 inspected the saved safetensors directly: 256 FP32 tensors, 128 A/B pairs, all finite, all B matrices nonzero, 84,972,248 bytes. SHA-256 `bd22988e32b879487243946b3165a54e775ce26f39c63be335ce7ec6efc10b25`. The base weights are absent here, so adapter norms cannot establish causal damage or relative update magnitude. `evidence/adapter_audit.json` contains exact measured norms.

The main regression is compilation, not output parsing: base has 6 compile errors, 6 invalid responses, 6 test failures, and 12 passes. Adapter has 16 compile errors, 2 invalid responses, 6 test failures, and 6 passes. The generation subgroup drops 9/21 to 2/21; repair rises 3/9 to 4/9. The archived relaxed format rescore rescued no pass. Six base responses and two adapter responses hit the 128-token cap. On the exploratory selected 14-case subset, the step-8 checkpoint was already at 0/14 vs 7/14 base and 1/14 final adapter. These observations are compatible with early overadaptation to a tiny set and a shift toward shorter but type-incorrect bodies; they do not prove a causal mechanism. No GLM data qualified for the original training run; this was verified-reference SFT, not frontier distillation.

## 2. Method and actual replay results

The base emits a fenced Rust function body. A strict format and compile-only gate checks the candidate using just the public signature and imports. If compiling, keep it. If malformed or noncompiling, call the specialist once; replace the first candidate only if the fallback compiles. Functional tests are reserved for independent scoring. A separate base-only diagnostic retry is the equal-call control. Compilation is necessary in this setup but not sufficient for correctness.

Archived gate proxy maps `pass` and `test_failure` to the *same* `compiled` status. Other statuses remain format or compiler rejection. This proxy is derived from original full-verifier results, not a fresh standalone compile; the new experiment uses the separate compiler gate without hidden test harness. The policy never chooses on actual functional pass/fail. Results below were computed locally from all archived outputs; no fresh GPU inference or Rust execution took place.

| Policy | Passes/30 | Compiled/30 | Repair/9 | Generation/21 | Calls | Generated tokens | Recorded generation seconds | Gains / losses vs base |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Base one shot | 12 | 18 | 3 | 9 | 30 | 2614 | 231.58 | 0 / 0 |
| Adapter one shot | 6 | 12 | 4 | 2 | 30 | 1518 | 181.76 | 4 / 10 |
| Mode router | 13 | 20 | 4 | 9 | 30 | 2388 | 224.54 | 3 / 2 |
| Base first, specialist if rejected | **16** | **23** | **6** | **10** | 42 | 3331 | 317.20 | **4 / 0** |
| Repair-first cascade | 15 | 23 | 5 | 10 | 40 | 3012 | 293.40 | 4 / 1 |
| Adapter-first cascade | 14 | 23 | 5 | 9 | 48 | 3107 | 322.36 | 4 / 2 |

Any-candidate oracle = 16/30. Base-first reaches that ceiling on this particular old set without consulting functional outcomes. It is not guaranteed on new tasks. Exact paired sign/McNemar test for base-first vs base gives descriptive p=0.125 (4 discordant gains, zero losses). Policy discovery and measurement used the same cases, so no inferential claim is justified. Absolute improvement +13.33 percentage points, relative improvement +33.33%. 40% more model calls, 27.4% more generated tokens, and 37.0% more recorded generation time. Generation-only cost per solved task is ~19.30 s base vs ~19.83 s cascade. No evidence of a compute reduction. Latency excludes compiler time and switching overhead; actual live timing remains pending. Report selected final system accuracy, not one-shot model pass@1 or pass@2.

## 3. Fresh falsification experiment (implemented, NOT RUN here)

`source/fresh.py` pins the original HumanEvalPack Rust file, verifies the SHA-256, excludes all old underlying HumanEval problem IDs from both public suites, heuristically filters near-duplicate specs, deterministically orders the remaining problems, and requires 30 generation + 30 repair unique problem IDs with a genuinely passing reference and failing published broken control. If 60 cannot be qualified, abort; do not quietly lower the sample. HumanEvalPack is MIT-tagged on the Hub; it is a public benchmark, so base-model pretraining exposure is unknown. No public benchmark rows are used for new training. Freeze the exact manifest and digest before inference.

`source/run_fresh.py` reuses the pinned base and authentic existing adapter. All three arms share the same initial base output and 128-token greedy cap: (A) one-shot base, (B) compiler-gated specialist, (C) same-call base retry with previous response and compiler diagnostic. The specialist arm uses the original prompt, matching archived behavior. The base feedback arm is intentionally strong, not artificially weakened by repeated identical greedy decoding. Both retry arms run on exactly the same initial rejections. Actual tokens, generation time, compiler time, peak GPU allocation and functional outcomes are recorded. Candidate selections are written and hashed before any hidden functional tests are scored. Public task view contains only spec/prompt, signature, imports and mode, not tests or gold body.

Proposed promotion rule chosen before fresh inference: at least 6 additional passes / 60 (+10 points) over base, strictly more passes than same-call base feedback, zero lost previously passed cases, no generation or repair regression, and no reduction in compiling outputs. Report paired counts and exact p; this numerical gate does not establish statistical significance. If not met, retain base. Do not try alternate policies on the final set and call them independently validated.

## 4. Training research direction

Do not repeat 48-step generic adaptation on 27 short answers. The better hypothesis is a *retry-specialist objective*: train specifically on compiler-rejected candidate bodies plus their actual diagnostics, with verified corrected targets. Keep clean base supervision as retention control, split by underlying operation/source, and compare feedback-trained adapter with base feedback and the original step-48 adapter on disjoint development tasks. Start fresh from the base, rank 8, LR 1e-5–2e-5, short checkpoints, and choose by functional recovery, not loss. Obtain at least 150 distinct eligible training operations before a larger run. These are proposed choices, not performed experiments; data provenance and independent replay remain prerequisites. The Mission 01 corpus and teacher audit show why a large raw dataset is not sufficient.

## 5. Related work / claims boundary

- Le et al., CodeRL, NeurIPS 2022: uses unit-test outcomes for learning and regeneration. https://proceedings.neurips.cc/paper_files/paper/2022/hash/8636419dea1aa9fbd25fc4248e702da4-Abstract-Conference.html
- Ni et al., LEVER, ICML 2023: learns to rerank candidates from execution results. https://proceedings.mlr.press/v202/ni23b.html
- Chen et al., Teaching Large Language Models to Self-Debug, ICLR 2024: uses iterative debugging and execution feedback. https://proceedings.iclr.cc/paper_files/paper/2024/hash/2460396f2d0d421885997dd1612ac56b-Abstract-Conference.html
- RustAssistant, ICSE 2025: compiler-feedback-driven Rust repair on real repositories. https://ieeexplore.ieee.org/document/11029935/
- HumanEvalPack / OctoPack, BigCode: https://huggingface.co/datasets/bigcode/humanevalpack

Celestica does not invent verification, compiler feedback, LoRA, or conditional model routing. The student research contribution is this specific low-budget, regression-protecting experiment, its measurements and transparent exhibit. A genuine competitive school project can be built on a well-controlled experiment rather than claiming frontier-level capability.

## 6. Operational limitations

This session's container has no CUDA GPU, no Rust toolchain, no Wasmtime, and no network resolution for toolchain installation. The original artifact was recovered and audited. Local software tests include mocked compiler and browser interactions; they do not substitute for actual Rust compilation, sandbox penetration testing or GPU evaluation. The existing WASI verifier is a constrained pilot; host-side compiler isolation has not been independently security-audited. Only curated code tasks are offered. New demo references require real verification before use. No paid remote job or public repository write occurred. Additional paid expenditure ₹0. Final exhibition competition readiness remains partial until fresh evaluation and live deployment are actually rehearsed.
