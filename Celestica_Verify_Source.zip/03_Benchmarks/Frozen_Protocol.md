# Frozen evaluation protocol

The original model, archived adapter and retrospective results are development evidence. Freeze a new HumanEvalPack set by the Mission 02 rule, excluding previously used IDs and near-duplicate specifications. The pinned Rust dataset is at revision 9a41762f73a8cb23bb5811b73d5aab164efcf378. Qualify 30 generation and 30 repair tasks by executing references and negative controls in an isolated Rust and WASI environment. Historical public benchmark pretraining exposure is unknown.

## Compiler-only study

Use the same 60 underlying problems and their publisher-provided buggy solutions. Compare the original negative control with one complete machine-applicable rustc suggestion wholly within its body. Keep the edit only when it compiles. The compiler sees the public function signature and imports with no functional assertions. Freeze selections first. Use functional checks afterward. Report coverage, paired counts, costs and uncertainty. Budget 3 workers and 10 minutes, ₹0 paid expenditure, zero model calls. This is a mechanism study using known-bad code.

## Independent model comparison and promotion

Use the same shared original output across the one-shot, compiler-gated old adapter and base-with-feedback conditions. Match retry trigger, number of model calls, output cap and compiler feedback when directly comparing models. Run alternate arms for feedback, deterministic compiler edits and the newly trained adapter when available. Keep blind outcomes outside routing and model selection. Report paired gains and losses with uncertainty, functional accuracy, compilation, output validity, subgroups, generated tokens and compute. Promote only if the gain is at least 10 percentage points over the matched base, the challenger beats matched retries or demonstrates a measured accuracy-cost advantage, and there is no material unexplained regression. No tuning on the frozen cases is allowed.
